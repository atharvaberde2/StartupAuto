import praw
from openai import OpenAI
import time
import json

class ProjectProblemFinder:
    def __init__(self, openai_api_key, reddit_client_id, reddit_client_secret, reddit_user_agent):
        """
        Initialize the problem finder with API credentials.
        """
        # Set up OpenAI (v1.0+ format)
        self.openai_client = OpenAI(api_key=openai_api_key)
        
        # Set up Reddit
        self.reddit = praw.Reddit(
            client_id=reddit_client_id,
            client_secret=reddit_client_secret,
            user_agent=reddit_user_agent
        )
        
    def extract_problem_keywords(self, project_idea):
        """
        Use GPT-4 with few-shot examples to extract natural problem keywords.
        
        Args:
            project_idea (str): Description of your project idea
            
        Returns:
            list: List of problem-focused keywords for Reddit search
        """
        
        prompt = f"""You are an expert at finding how real people express problems on Reddit. Your job is to generate natural, user-focused keywords that will find actual problem threads.

EXAMPLES:

Project: "A budgeting app that tracks expenses and sends spending alerts"
Keywords: ["can't stick to budget", "money disappears too fast", "overspending again", "budget apps don't work", "terrible with money", "impulse buying problem", "how to stop spending", "broke by month end", "budget keeps failing", "spending addiction help"]

Project: "A meditation app with guided sessions and progress tracking"  
Keywords: ["can't meditate properly", "mind won't stop racing", "meditation too hard", "can't sit still", "anxious all the time", "meditation apps boring", "trouble focusing", "stress overwhelming me", "need calm down", "meditation not working"]

Project: "A habit tracker for daily routines and goal achievement"
Keywords: ["can't stick to habits", "always breaking streaks", "motivation disappears", "habit apps don't help", "terrible at routines", "give up too easily", "inconsistent with goals", "procrastination problem", "discipline issues", "habits never stick"]

NOW YOUR TURN:

Project: "{project_idea}"

Generate 12-15 keywords that capture how REAL people naturally complain about or ask for help with problems this project would solve.

Rules:
- Use conversational language (not technical terms)
- Focus on frustrations, complaints, and help-seeking
- Include emotional expressions ("terrible at", "can't", "always")
- Think about what someone would actually type on Reddit
- Avoid app-specific jargon

Return ONLY a Python list:
["keyword1", "keyword2", ...]"""
        
        try:
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that generates natural, user-focused keywords for Reddit searches. Return only a Python list of strings."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                temperature=0.7
            )
            
            # Extract the keywords from the response
            keywords_text = response.choices[0].message.content.strip()
            
            # Parse the Python list string
            try:
                keywords = eval(keywords_text)  # Safe here since we control the input
                if isinstance(keywords, list):
                    print(f"GPT-4 extracted {len(keywords)} problem-focused keywords:")
                    for i, kw in enumerate(keywords, 1):
                        print(f"  {i}. {kw}")
                    return keywords
                else:
                    print("GPT-4 didn't return a proper list format")
                    return []
            except:
                print("Error parsing GPT-4 response as Python list")
                print(f"Raw response: {keywords_text}")
                return []
                
        except Exception as e:
            print(f"Error calling GPT-4: {e}")
            return self.get_fallback_keywords(project_idea)
    
    def get_fallback_keywords(self, project_idea):
        """
        Fallback keywords if GPT-4 fails, based on the project idea.
        """
        print("Using fallback keywords...")
        
        # Create fallback keywords based on project idea
        project_lower = project_idea.lower()
        fallback_keywords = []
        
        # For water/hydration apps
        if "water" in project_lower or "hydration" in project_lower or "drink" in project_lower:
            fallback_keywords = [
                "forget to drink water",
                "terrible at staying hydrated", 
                "how to remember to drink water",
                "struggling to drink enough water",
                "never drink enough water",
                "remind me to drink water",
                "bad at drinking water",
                "dehydrated all the time",
                "water intake too low",
                "building water drinking habit"
            ]
        # For fitness apps
        elif "fitness" in project_lower or "health" in project_lower:
            fallback_keywords = [
                "can't lose weight", "workout not working", "diet problems", "exercise too hard",
                "fitness plateau", "can't stick to routine", "gym intimidating", "nutrition confusing"
            ]
        # For finance apps
        elif "finance" in project_lower or "money" in project_lower:
            fallback_keywords = [
                "can't budget properly", "money always tight", "investing too risky", "debt overwhelming",
                "financial stress", "can't save money", "budget apps don't work", "expense tracking hard"
            ]
        else:
            # Generic fallback with PROBLEM focus
            main_terms = project_idea.split()[:3]  # First 3 words
            for term in main_terms:
                if len(term) > 3:
                    fallback_keywords.extend([
                        f"can't understand {term}",
                        f"{term} too complicated", 
                        f"struggling with {term}",
                        f"{term} doesn't work"
                    ])
        
        return fallback_keywords[:12]

    def search_problem_threads_enhanced(self, keywords, limit_total=50):
        """
        Enhanced search across ALL of Reddit with multiple strategies.
        """
        if not keywords:
            print("No keywords provided for search")
            return []
        
        all_threads = []
        
        # Strategy 1: Search all Reddit with OR query
        print(f"\n🔍 Strategy 1: Searching ALL Reddit with OR query...")
        or_query = " OR ".join([f'"{keyword}"' for keyword in keywords[:10]])  # Limit to avoid too long query
        threads_or = self._search_reddit_with_query(or_query, limit_total//3, "all")
        all_threads.extend(threads_or)
        
        # Strategy 2: Search individual keywords across all Reddit
        print(f"\n🔍 Strategy 2: Searching individual keywords...")
        for keyword in keywords[:8]:  # Top 8 keywords
            print(f"   Searching: '{keyword}'")
            threads_single = self._search_reddit_with_query(f'"{keyword}"', 5, "all")
            all_threads.extend(threads_single)
            time.sleep(0.5)  # Rate limiting
        
        # Strategy 3: Search specific relevant subreddits
        print(f"\n🔍 Strategy 3: Searching relevant subreddits...")
        relevant_subreddits = self._get_relevant_subreddits(keywords)
        
        for subreddit_name in relevant_subreddits:
            print(f"   Searching r/{subreddit_name}...")
            for keyword in keywords[:5]:  # Top 5 keywords per subreddit
                try:
                    threads_sub = self._search_reddit_with_query(f'"{keyword}"', 3, subreddit_name)
                    all_threads.extend(threads_sub)
                    time.sleep(0.3)  # Rate limiting
                except Exception as e:
                    print(f"   Error searching r/{subreddit_name}: {e}")
                    continue
        
        # Strategy 4: Broader terms without quotes
        print(f"\n🔍 Strategy 4: Broader searches without quotes...")
        broad_terms = self._extract_broad_terms(keywords)
        for term in broad_terms:
            print(f"   Broad search: '{term}'")
            threads_broad = self._search_reddit_with_query(term, 5, "all")
            all_threads.extend(threads_broad)
            time.sleep(0.5)
        
        # Remove duplicates and score threads
        unique_threads = self._deduplicate_and_score_threads(all_threads)
        
        print(f"\n📊 Total unique threads found: {len(unique_threads)}")
        return unique_threads

    def _search_reddit_with_query(self, query, limit, subreddit_name):
        """
        Helper method to search Reddit with a specific query.
        """
        threads = []
        
        try:
            if subreddit_name == "all":
                search_results = self.reddit.subreddit("all").search(
                    query=query,
                    limit=min(limit, 10),  # Cap at 10 for speed
                    sort="relevance",
                    time_filter="year"  # Search past year only for speed
                )
            else:
                search_results = self.reddit.subreddit(subreddit_name).search(
                    query=query,
                    limit=min(limit, 10),  # Cap at 10 for speed
                    sort="relevance",
                    time_filter="year"  # Search past year only for speed
                )
            
            for submission in search_results:
                # Problem indicators
                problem_indicators = [
                    "help", "issue", "problem", "error", "can't", "won't", "doesn't work", 
                    "broken", "fix", "trouble", "struggling", "difficulty", "not working",
                    "how to", "why", "what's wrong", "stuck", "failed", "bug", "advice",
                    "tips", "recommend", "best way", "anyone know", "need help", "terrible at",
                    "bad at", "forget", "never remember", "always", "never"
                ]
                
                title_lower = submission.title.lower()
                selftext_lower = submission.selftext.lower() if submission.selftext else ""
                
                # Score how "problem-like" this thread is
                problem_score = sum(1 for indicator in problem_indicators 
                                  if indicator in title_lower or indicator in selftext_lower)
                
                # Find matched keywords
                matched_keywords = []
                for kw in [query.replace('"', '')]:  # Remove quotes for matching
                    if kw.lower() in title_lower or kw.lower() in selftext_lower:
                        matched_keywords.append(kw)
                
                # Ensure proper permalink format
                permalink = submission.permalink
                if not permalink.startswith('https://'):
                    permalink = f"https://reddit.com{permalink}"
                
                thread_data = {
                    "title": submission.title,
                    "url": submission.url,
                    "permalink": permalink,  # Guaranteed full URL
                    "subreddit": str(submission.subreddit),
                    "score": submission.score,
                    "num_comments": submission.num_comments,
                    "created_utc": submission.created_utc,
                    "author": str(submission.author) if submission.author else "[deleted]",
                    "selftext": submission.selftext[:300] + "..." if submission.selftext and len(submission.selftext) > 300 else submission.selftext or "",
                    "is_self": submission.is_self,
                    "over_18": submission.over_18,
                    "problem_score": problem_score,
                    "is_question": submission.title.endswith('?') or '?' in submission.title,
                    "search_query": query,
                    "found_in_subreddit": subreddit_name,
                    "matched_keywords": matched_keywords
                }
                threads.append(thread_data)
                
        except Exception as e:
            print(f"   Error searching with query '{query}': {e}")
        
        return threads

    def _get_relevant_subreddits(self, keywords):
        """
        Determine relevant subreddits based on keywords.
        """
        # Water/hydration related subreddits
        water_fitness_subs = [
            "fitness", "loseit", "getmotivated", "selfimprovement", 
            "productivity", "HealthyFood", "nutrition", "running",
            "bodybuilding", "xxfitness", "flexibility", "yoga", "weightloss",
            "HydroHomies", "ADHD", "adhdwomen"
        ]
        
        # App/tech related subreddits  
        tech_subs = [
            "androidapps", "iosapps", "apps", "Android", "iphone",
            "productivity", "LifeProTips", "getmotivated"
        ]
        
        # Health related subreddits
        health_subs = [
            "AskDocs", "nutrition", "HealthyFood", "medical", 
            "migraine", "Skincare_Addiction", "intermittentfasting", "keto",
            "pregnant", "BabyBumps"
        ]
        
        # General advice/help subreddits
        general_subs = [
            "AskReddit", "LifeProTips", "NoStupidQuestions", 
            "TooAfraidToAsk", "explainlikeimfive", "YouShouldKnow",
            "personalproductivity", "getdisciplined"
        ]
        
        # Combine all relevant subreddits
        all_subs = water_fitness_subs + tech_subs + health_subs + general_subs
        
        # Remove duplicates and return
        return list(set(all_subs))

    def _extract_broad_terms(self, keywords):
        """
        Extract broader, more general terms from specific keywords.
        """
        broad_terms = []
        
        for keyword in keywords:
            # Extract key terms without quotes
            words = keyword.replace('"', '').split()
            
            # Look for important terms
            important_words = []
            for word in words:
                if len(word) > 3 and word not in ['with', 'that', 'this', 'when', 'have', 'been', 'they', 'from', 'need', 'want', 'very', 'much']:
                    important_words.append(word)
            
            # Create broader terms
            if important_words:
                if len(important_words) >= 2:
                    broad_terms.append(' '.join(important_words[:2]))
                else:
                    broad_terms.append(important_words[0])
        
        # Add some general terms based on project type
        broad_terms.extend(['water', 'hydration', 'drink', 'reminder', 'habit', 'tracking'])
        
        # Remove duplicates
        return list(set(broad_terms))

    def _deduplicate_and_score_threads(self, threads):
        """
        Remove duplicate threads and score them for relevance.
        """
        seen_urls = set()
        unique_threads = []
        
        for thread in threads:
            if thread['permalink'] not in seen_urls:
                seen_urls.add(thread['permalink'])
                unique_threads.append(thread)
        
        # Sort by problem score and engagement
        unique_threads.sort(key=lambda x: (x['problem_score'], x['score'], x['num_comments']), reverse=True)
        
        return unique_threads
    
    def analyze_and_search(self, project_idea, limit_total=80):
        """
        Complete workflow: Extract keywords from project idea and search for problem threads.
        
        Args:
            project_idea (str): Your project idea description
            limit_total (int): Number of threads to find
            
        Returns:
            dict: Contains keywords and threads
        """
        
        print("="*60)
        print("PROJECT PROBLEM FINDER - ENHANCED WITH LINKS")
        print("="*60)
        print(f"Project Idea: {project_idea}")
        print("\nStep 1: Extracting problem-focused keywords using GPT-4...")
        
        # Extract keywords using GPT-4
        keywords = self.extract_problem_keywords(project_idea)
        
        if not keywords:
            return {"keywords": [], "threads": []}
        
        print(f"\nStep 2: Comprehensive Reddit search across ALL subreddits...")
        
        # Use enhanced search
        threads = self.search_problem_threads_enhanced(keywords, limit_total)
        
        return {
            "keywords": keywords,
            "threads": threads
        }
    
    def display_results_with_links(self, results, show_top=15):
        """
        Display the search results with guaranteed clickable links for each thread.
        """
        
        keywords = results.get("keywords", [])
        threads = results.get("threads", [])
        
        print(f"\n" + "="*80)
        print("🔍 PROJECT PROBLEM FINDER - RESULTS WITH LINKS")
        print("="*80)
        print(f"Keywords used: {len(keywords)}")
        print(f"Total problem threads found: {len(threads)}")
        
        if threads:
            print(f"\n🔥 TOP {min(show_top, len(threads))} PROBLEM THREADS:")
            print("="*80)
            
            for i, thread in enumerate(threads[:show_top], 1):
                # Ensure we have a proper link
                link = thread.get('permalink', '')
                if not link.startswith('https://'):
                    link = f"https://reddit.com{link}" if link else f"https://reddit.com/r/{thread.get('subreddit', 'unknown')}"
                
                print(f"\n🎯 #{i}")
                print(f"📝 TITLE: {thread['title']}")
                print(f"🏠 SUBREDDIT: r/{thread['subreddit']}")
                print(f"📊 ENGAGEMENT: ↑{thread['score']} upvotes | 💬{thread['num_comments']} comments")
                print(f"🔥 PROBLEM SCORE: {thread.get('problem_score', 0)}/10")
                
                # Show matched keywords if available
                if thread.get('matched_keywords'):
                    keywords_str = ', '.join(thread['matched_keywords'][:3])  # Show first 3
                    if len(thread['matched_keywords']) > 3:
                        keywords_str += f" (+{len(thread['matched_keywords'])-3} more)"
                    print(f"🎯 MATCHED: {keywords_str}")
                
                # Show preview of content
                if thread.get('selftext') and thread['selftext'].strip() and thread['selftext'] != '...':
                    preview = thread['selftext'][:200].replace('\n', ' ').strip()
                    if preview:
                        print(f"📖 PREVIEW: {preview}...")
                
                # THE MOST IMPORTANT PART - GUARANTEED CLICKABLE LINK
                print(f"🔗 DIRECT LINK: {link}")
                
                print("-" * 80)
        
        else:
            print("\n❌ No problem threads found. Try:")
            print("   - Broadening your keywords")
            print("   - Checking different time periods") 
            print("   - Searching specific subreddits manually")

    def export_results_with_links(self, results, filename="problem_threads_with_links.txt"):
        """
        Export all results to a text file with clickable links.
        """
        threads = results.get("threads", [])
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("PROJECT PROBLEM FINDER - ALL RESULTS WITH LINKS\n")
            f.write("="*60 + "\n\n")
            f.write(f"Total threads found: {len(threads)}\n\n")
            
            for i, thread in enumerate(threads, 1):
                # Ensure proper link format
                link = thread.get('permalink', '')
                if not link.startswith('https://'):
                    link = f"https://reddit.com{link}" if link else f"https://reddit.com/r/{thread.get('subreddit', 'unknown')}"
                
                f.write(f"#{i}. {thread['title']}\n")
                f.write(f"Subreddit: r/{thread['subreddit']}\n")
                f.write(f"Score: {thread['score']} | Comments: {thread['num_comments']}\n")
                f.write(f"Problem Score: {thread.get('problem_score', 0)}/10\n")
                f.write(f"Link: {link}\n")
                
                if thread.get('selftext') and thread['selftext'].strip():
                    preview = thread['selftext'][:300].replace('\n', ' ').strip()
                    f.write(f"Preview: {preview}...\n")
                
                f.write("\n" + "-"*60 + "\n\n")
        
        print(f"✅ All {len(threads)} threads exported to '{filename}'")

    def create_subreddit_breakdown_with_links(self, results):
        """
        Create a breakdown by subreddit with sample links from each.
        """
        threads = results.get("threads", [])
        
        # Group by subreddit
        subreddit_groups = {}
        for thread in threads:
            sub = thread['subreddit']
            if sub not in subreddit_groups:
                subreddit_groups[sub] = []
            subreddit_groups[sub].append(thread)
        
        print(f"\n🏠 DETAILED SUBREDDIT BREAKDOWN WITH SAMPLE LINKS:")
        print("="*70)
        
        # Sort by number of threads found
        for sub, sub_threads in sorted(subreddit_groups.items(), key=lambda x: len(x[1]), reverse=True):
            print(f"\nr/{sub}: {len(sub_threads)} threads")
            print("-" * 40)
            
            # Show top 3 threads from each subreddit as examples
            for i, thread in enumerate(sub_threads[:3], 1):
                link = thread.get('permalink', '')
                if not link.startswith('https://'):
                    link = f"https://reddit.com{link}" if link else f"https://reddit.com/r/{sub}"
                    
                print(f"  {i}. {thread['title'][:60]}...")
                print(f"     ↑{thread['score']} | 💬{thread['num_comments']} | Score: {thread.get('problem_score', 0)}/10")
                print(f"     🔗 {link}")
                print()

# Initialize and use the problem finder
def main():
    # Your API credentials - REPLACE WITH YOUR ACTUAL CREDENTIALS
    OPENAI_API_KEY = "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"
    REDDIT_CLIENT_ID = "rWFSMJ5AuPPdHkPbWvoySg"
    REDDIT_CLIENT_SECRET = "_fk9tcrcdqEV8YWg57PVGAxHD-OjYQ"
    REDDIT_USER_AGENT = "Ath"
    
    # Initialize the problem finder
    finder = ProjectProblemFinder(
        openai_api_key=OPENAI_API_KEY,
        reddit_client_id=REDDIT_CLIENT_ID,
        reddit_client_secret=REDDIT_CLIENT_SECRET,
        reddit_user_agent=REDDIT_USER_AGENT
    )
    
    # Your project idea - REPLACE THIS WITH YOUR ACTUAL PROJECT IDEA
    project_idea = """
    A mobile app that helps people track their daily water intake and reminds them to drink water throughout the day. 
    The app would send smart notifications, track hydration goals, and integrate with fitness trackers.
    """
    
    # Run the complete analysis with enhanced search
    results = finder.analyze_and_search(project_idea, limit_total=100)
    
    # Display results with guaranteed links
    finder.display_results_with_links(results, show_top=20)
    
    # Export all results to text file with links
    finder.export_results_with_links(results, "water_app_problems_with_links.txt")
    
    # Show detailed subreddit breakdown with sample links
    finder.create_subreddit_breakdown_with_links(results)
    
    # Save results to JSON for later analysis
    with open('comprehensive_problem_analysis_with_links.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print(f"\n" + "="*70)
    print("📋 FINAL SUMMARY")
    print("="*70)
    print(f"✅ Found {len(results['threads'])} total problem threads")
    print(f"✅ Across {len(set(t['subreddit'] for t in results['threads']))} different subreddits")
    print(f"✅ All threads saved with clickable links to:")
    print(f"   📄 water_app_problems_with_links.txt")
    print(f"   📄 comprehensive_problem_analysis_with_links.json")
    print(f"\n🎯 You can now click any link to see actual user problems!")
    print(f"🎯 Perfect for validating your water tracking app idea!")
    
    # Print subreddit breakdown summary
    if results['threads']:
        print(f"\n📊 TOP SUBREDDITS BY THREAD COUNT:")
        subreddit_count = {}
        for thread in results['threads']:
            sub = thread['subreddit']
            subreddit_count[sub] = subreddit_count.get(sub, 0) + 1
        
        for sub, count in sorted(subreddit_count.items(), key=lambda x: x[1], reverse=True)[:10]:
            print(f"   r/{sub}: {count} threads")

def extract_links_from_existing_results(json_filename="comprehensive_problem_analysis_with_links.json"):
    """
    Extract and organize all links from existing results file.
    """
    
    try:
        with open(json_filename, 'r') as f:
            results = json.load(f)
        
        threads = results.get('threads', [])
        print(f"🔍 EXTRACTING LINKS FROM {len(threads)} THREADS")
        print("="*60)
        
        # Group by subreddit for better organization
        subreddit_threads = {}
        for thread in threads:
            sub = thread.get('subreddit', 'unknown')
            if sub not in subreddit_threads:
                subreddit_threads[sub] = []
            subreddit_threads[sub].append(thread)
        
        all_links = []
        
        # Display organized by subreddit
        for sub, sub_threads in sorted(subreddit_threads.items(), key=lambda x: len(x[1]), reverse=True):
            print(f"\n🏠 r/{sub} ({len(sub_threads)} threads):")
            print("-" * 50)
            
            for i, thread in enumerate(sub_threads, 1):
                # Ensure proper link format
                link = thread.get('permalink', '')
                if not link.startswith('https://'):
                    link = f"https://reddit.com{link}" if link else f"https://reddit.com/r/{sub}"
                
                title = thread.get('title', 'No title')[:80]
                score = thread.get('score', 0)
                comments = thread.get('num_comments', 0)
                problem_score = thread.get('problem_score', 0)
                
                print(f"  {i}. {title}")
                print(f"     ↑{score} | 💬{comments} | Problem Score: {problem_score}/10")
                print(f"     🔗 {link}")
                print()
                
                all_links.append({
                    'title': thread.get('title', ''),
                    'subreddit': sub,
                    'link': link,
                    'score': score,
                    'comments': comments,
                    'problem_score': problem_score
                })
        
        # Save all links to a simple text file
        with open('all_water_problem_links_organized.txt', 'w', encoding='utf-8') as f:
            f.write("WATER APP PROBLEM THREADS - ALL LINKS ORGANIZED\n")
            f.write("="*60 + "\n\n")
            f.write(f"Total threads: {len(all_links)}\n\n")
            
            # Group by subreddit in the file too
            for sub, sub_threads in sorted(subreddit_threads.items(), key=lambda x: len(x[1]), reverse=True):
                f.write(f"\nr/{sub} ({len(sub_threads)} threads):\n")
                f.write("-" * 40 + "\n")
                
                for i, thread in enumerate(sub_threads, 1):
                    link = thread.get('permalink', '')
                    if not link.startswith('https://'):
                        link = f"https://reddit.com{link}" if link else f"https://reddit.com/r/{sub}"
                    
                    f.write(f"{i}. {thread.get('title', 'No title')}\n")
                    f.write(f"   Score: {thread.get('score', 0)} | Comments: {thread.get('num_comments', 0)}\n")
                    f.write(f"   Problem Score: {thread.get('problem_score', 0)}/10\n")
                    f.write(f"   Link: {link}\n\n")
        
        print(f"\n✅ Organized {len(all_links)} links by subreddit")
        print(f"✅ Saved to 'all_water_problem_links_organized.txt'")
        
        return all_links
        
    except FileNotFoundError:
        print(f"❌ Could not find {json_filename}")
        print("Run the main script first to generate results.")
        return []
    except Exception as e:
        print(f"❌ Error reading results: {e}")
        return []

if __name__ == "__main__":
    print("🚀 PROJECT PROBLEM FINDER")
    print("="*40)
    print("1. Run full problem analysis")
    print("2. Extract links from existing results")
    
    choice = input("\nChoose option (1 or 2): ").strip()
    
    if choice == "2":
        # Extract links from existing results
        extract_links_from_existing_results()
    else:
        # Run full analysis
        main()