"""
Quick test script to check if Bright Data API is working with different collector formats
"""
import asyncio
import aiohttp
import json
from config import Config

async def test_bright_data_api():
    """Test Bright Data API connectivity with different collector formats"""
    config = Config()
    
    print("🔍 Testing Bright Data API Configuration...")
    print(f"API Key: {config.BRIGHT_DATA_API_KEY[:20]}***")
    print(f"Collector: {config.BRIGHT_DATA_COLLECTOR_ID}")
    
    # Test endpoint
    test_url = "https://api.brightdata.com/dca/trigger"
    
    headers = {
        "Authorization": f"Bearer {config.BRIGHT_DATA_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Test different collector parameter formats
    test_payloads = [
        {
            "url": "https://httpbin.org/get",
            "format": "json", 
            "collector": config.BRIGHT_DATA_COLLECTOR_ID
        },
        {
            "url": "https://httpbin.org/get",
            "format": "json",
            "collector_id": config.BRIGHT_DATA_COLLECTOR_ID
        },
        {
            "url": "https://httpbin.org/get",
            "format": "json",
            "zone": config.BRIGHT_DATA_COLLECTOR_ID
        }
    ]
    
    try:
        async with aiohttp.ClientSession() as session:
            print(f"\n📡 Testing API endpoint: {test_url}")
            
            for i, test_payload in enumerate(test_payloads, 1):
                print(f"\n🧪 Test {i}/3 - Format: {list(test_payload.keys())}")
                print(f"Payload: {test_payload}")
                
                try:
                    async with session.post(test_url, headers=headers, json=test_payload, timeout=15) as response:
                        print(f"Status Code: {response.status}")
                        
                        if response.status == 200:
                            data = await response.json()
                            print(f"✅ SUCCESS! Format works: {list(test_payload.keys())}")
                            print(f"Response preview: {json.dumps(data, indent=2)[:200]}...")
                            return True
                        else:
                            response_text = await response.text()
                            print(f"❌ Failed: {response_text}")
                            
                except Exception as e:
                    print(f"❌ Request failed: {str(e)}")
                    
                print("-" * 50)
            
            print("\n❌ All collector formats failed")
            return False
                    
    except Exception as e:
        print(f"❌ Connection error: {str(e)}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("🚀 BRIGHT DATA API COLLECTOR TEST")
    print("=" * 60)
    
    success = asyncio.run(test_bright_data_api())
    
    print("\n" + "=" * 60)
    print("📊 FINAL RESULT:")
    if success:
        print("✅ Bright Data API working!")
    else:
        print("❌ Bright Data API configuration issues")
    print("=" * 60)
