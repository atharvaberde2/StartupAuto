"""
Quick test script to check if Bright Data API is working
"""
import asyncio
import aiohttp
import json
from config import Config

async def test_bright_data_api():
    """Test Bright Data API connectivity"""
    config = Config()
    
    print("🔍 Testing Bright Data API Configuration...")
    print(f"API Key: {config.BRIGHT_DATA_API_KEY[:20]}***")
    print(f"Username: {config.BRIGHT_DATA_USERNAME}")
    print(f"Zone: {config.BRIGHT_DATA_ZONE}")
    print(f"Endpoint: {config.BRIGHT_DATA_ENDPOINT}")
    
    # Test Bright Data DCA (Data Collection API) endpoint 
    test_url = "https://api.brightdata.com/dca/trigger"
    
    headers = {
        "Authorization": f"Bearer {config.BRIGHT_DATA_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Test different collector formats
    test_payloads = [
        {
            "url": "https://httpbin.org/get",
            "format": "json", 
            "collector": config.BRIGHT_DATA_COLLECTOR_ID
        },
        {
            "url": "https://httpbin.org/get",
            "format": "json",
            "collector_id": config.BRIGHT_DATA_COLLECTOR_ID
        },
        {
            "url": "https://httpbin.org/get",
            "format": "json",
            "zone": config.BRIGHT_DATA_COLLECTOR_ID
        }
    ]
    
    try:
        async with aiohttp.ClientSession() as session:
            print(f"\n📡 Testing API endpoint: {test_url}")
            print(f"Test payload: {test_payload}")
            
            async with session.post(test_url, headers=headers, json=test_payload, timeout=30) as response:
                print(f"Status Code: {response.status}")
                print(f"Response Headers: {dict(response.headers)}")
                
                if response.status == 200:
                    data = await response.json()
                    print(f"✅ API Working! Response: {json.dumps(data, indent=2)[:200]}...")
                    return True
                elif response.status == 401:
                    print("❌ Authentication Failed - Check API Key")
                    return False
                elif response.status == 403:
                    print("❌ Forbidden - Check permissions")
                    return False
                else:
                    text = await response.text()
                    print(f"❌ API Error {response.status}: {text[:200]}...")
                    return False
                    
    except asyncio.TimeoutError:
        print("❌ Request timed out")
        return False
    except Exception as e:
        print(f"❌ Connection error: {str(e)}")
        return False

async def test_web_scraping():
    """Test basic web scraping capability"""
    config = Config()
    
    print("\n🌐 Testing Web Scraping Capability...")
    
    # Test simple web request
    test_url = "https://httpbin.org/get"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(test_url, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"✅ Web scraping works! IP: {data.get('origin', 'Unknown')}")
                    return True
                else:
                    print(f"❌ Web request failed: {response.status}")
                    return False
    except Exception as e:
        print(f"❌ Web scraping error: {str(e)}")
        return False

async def main():
    """Run all tests"""
    print("=" * 60)
    print("🚀 BRIGHT DATA API TEST")
    print("=" * 60)
    
    # Test 1: Basic connectivity
    web_ok = await test_web_scraping()
    
    # Test 2: Bright Data API
    api_ok = await test_bright_data_api()
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 TEST RESULTS:")
    print(f"Web Connectivity: {'✅ PASS' if web_ok else '❌ FAIL'}")
    print(f"Bright Data API: {'✅ PASS' if api_ok else '❌ FAIL'}")
    
    if api_ok:
        print("\n🎉 Bright Data API is working correctly!")
        print("Your competitor analysis will use REAL data.")
    else:
        print("\n⚠️ Bright Data API issues detected.")
        print("Competitor analysis will use fallback simulation.")
        print("\nNext steps:")
        print("1. Check your Bright Data credentials")
        print("2. Verify API key permissions")
        print("3. Check account status at brightdata.com")
    
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(main())
