"""
Installation script for Startup Autopilot
Installs all required dependencies and sets up the environment
"""

import subprocess
import sys
import os

def install_requirements():
    """Install all required packages"""
    print("🚀 Installing Startup Autopilot dependencies...")
    
    try:
        # Install requirements
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ All dependencies installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def check_api_keys():
    """Check if API keys are configured"""
    print("\n🔑 Checking API key configuration...")
    
    from config import Config
    config = Config()
    
    keys_status = {
        "OpenAI API Key": bool(config.OPENAI_API_KEY and config.OPENAI_API_KEY.startswith('sk-')),
        "Reddit Client ID": bool(config.REDDIT_CLIENT_ID),
        "Reddit Client Secret": bool(config.REDDIT_CLIENT_SECRET),
        "News API Key": bool(config.NEWS_API_KEY),
        "Gemini API Key": bool(config.GEMINI_API_KEY)
    }
    
    all_configured = True
    for key_name, is_configured in keys_status.items():
        status = "✅" if is_configured else "❌"
        print(f"   {status} {key_name}: {'Configured' if is_configured else 'Missing'}")
        if not is_configured:
            all_configured = False
    
    if all_configured:
        print("\n✅ All API keys are configured!")
    else:
        print("\n⚠️  Some API keys are missing. Please update config.py with your API keys.")
        print("\nRequired API keys:")
        print("   • OpenAI API Key (for GPT-4 analysis)")
        print("   • Reddit Client ID & Secret (for Reddit analysis)")
        print("   • News API Key (for news analysis)")
        print("   • Google Gemini API Key (for competitor analysis)")
    
    return all_configured

def run_basic_test():
    """Run a basic test to verify the system works"""
    print("\n🧪 Running basic system test...")
    
    try:
        # Test imports
        from market_research_orchestrator import MarketResearchOrchestrator
        from config import Config
        
        # Initialize orchestrator
        orchestrator = MarketResearchOrchestrator()
        
        print("✅ System components loaded successfully!")
        return True
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ System test failed: {e}")
        return False

def main():
    """Main installation process"""
    print("=" * 60)
    print("🚀 STARTUP AUTOPILOT - INSTALLATION SETUP")
    print("=" * 60)
    
    # Step 1: Install dependencies
    if not install_requirements():
        print("\n❌ Installation failed at dependency installation step.")
        return False
    
    # Step 2: Check API keys
    keys_ok = check_api_keys()
    
    # Step 3: Basic system test
    if not run_basic_test():
        print("\n❌ Installation failed at system test step.")
        return False
    
    # Final status
    print("\n" + "=" * 60)
    if keys_ok:
        print("✅ INSTALLATION COMPLETED SUCCESSFULLY!")
        print("\nYou can now run the system:")
        print("   • python app.py (start the web interface)")
        print("   • python test_pipeline.py (test the pipeline)")
    else:
        print("⚠️  INSTALLATION PARTIALLY COMPLETED")
        print("\nNext steps:")
        print("   1. Configure your API keys in config.py")
        print("   2. Run: python app.py")
        print("   3. Test with: python test_pipeline.py")
    
    print("=" * 60)
    
    return True

if __name__ == "__main__":
    main()
