#!/usr/bin/env python3
"""
Create demo video files for advertisement generation
This creates placeholder MP4 files when real Veo 3 generation hits quota limits
"""

import os
import base64

def create_demo_video(filename, business_name="AI Market Validator"):
    """Create a simple demo MP4 file with embedded metadata"""
    
    # Minimal MP4 header with metadata for a 1-second black video
    # This creates a valid MP4 file that browsers can load
    mp4_data = base64.b64decode("""
    AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAAIZnJlZQAAAAhtZGF0AAABDQYF//8q3EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDE1MiByMjg2NCAKSDI2NAAtIGNvcmUgMTUyIHIyODY0IAp2aWRlbz8AAZFBmgwBIEEMAAEQAAAB8gAAAeQAAABBhiMqUQvCfEkEEEAB3QZGGqBADAIBAAAAwgAAAwAAAAMAAAABIgABCQAAAByAAALIgAAE0gKACQOgQQYTJwAIAFgAAAHrAAAA7QAAAoVZm5qaAAIDpyJWBAgAWAAAAewAAADsAAAA==
    """)
    
    # Create the video file
    with open(filename, 'wb') as f:
        f.write(mp4_data)
    
    print(f"✅ Created demo video: {filename}")
    return filename

def create_demo_audio(filename, business_name="AI Market Validator"):
    """Create a simple demo MP3 file"""
    
    # Minimal MP3 header for a silent audio file
    mp3_data = base64.b64decode("""
    //OxwAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//OxwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==
    """)
    
    with open(filename, 'wb') as f:
        f.write(mp3_data)
    
    print(f"✅ Created demo audio: {filename}")
    return filename

if __name__ == "__main__":
    # Create demo files for common business names
    businesses = [
        "AI Market Validator",
        "ai_market_validator", 
        "TrendSpotter AI",
        "CompetitorGPT",
        "PitchGen Pro"
    ]
    
    os.makedirs("static/generated", exist_ok=True)
    
    for business in businesses:
        safe_name = business.lower().replace(' ', '_').replace('-', '_')
        
        # Create video file
        video_file = f"static/generated/video_{safe_name}.mp4"
        create_demo_video(video_file, business)
        
        # Create audio file  
        audio_file = f"static/generated/voice_{safe_name}.mp3"
        create_demo_audio(audio_file, business)
    
    print("\n🎬 Demo media files created successfully!")
    print("These files will be served when Veo 3 quota is exceeded.")
