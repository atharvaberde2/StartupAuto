#!/usr/bin/env python3
"""
Create better demo video with actual visual content using opencv-python
"""

import os
import cv2
import numpy as np

def create_professional_demo_video(filename, business_name="AI Market Validator", duration=5):
    """Create a professional-looking demo video with text and graphics"""
    
    try:
        # Video properties
        width, height = 1920, 1080
        fps = 30
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        
        # Create video writer
        out = cv2.VideoWriter(filename, fourcc, fps, (width, height))
        
        # Calculate total frames
        total_frames = duration * fps
        
        print(f"🎬 Creating {duration}s demo video for {business_name}...")
        
        for frame_num in range(total_frames):
            # Create gradient background
            progress = frame_num / total_frames
            
            # Create a gradient from dark blue to purple
            img = np.zeros((height, width, 3), dtype=np.uint8)
            for y in range(height):
                color_factor = y / height
                blue = int(30 + color_factor * 60)  # 30-90
                green = int(20 + color_factor * 40)  # 20-60  
                red = int(60 + color_factor * 100)   # 60-160
                img[y, :] = [blue, green, red]
            
            # Add animated elements
            time_progress = (frame_num % 60) / 60  # 2-second cycle
            
            # Title text
            title_y = 300 + int(20 * np.sin(time_progress * 2 * np.pi))
            cv2.putText(img, business_name, (200, title_y), 
                       cv2.FONT_HERSHEY_SIMPLEX, 3, (255, 255, 255), 6)
            
            # Subtitle
            subtitle_y = 400 + int(10 * np.sin(time_progress * 2 * np.pi + 0.5))
            cv2.putText(img, "AI-Powered Business Validation", (250, subtitle_y), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1.5, (100, 200, 255), 3)
            
            # Progress indicator
            if frame_num > fps:  # Start after 1 second
                validation_progress = min(100, int((frame_num - fps) / fps * 25))
                cv2.putText(img, f"Validation Score: {validation_progress}%", (250, 600), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1.2, (100, 255, 100), 3)
                
                # Progress bar
                bar_width = int(400 * validation_progress / 100)
                cv2.rectangle(img, (250, 650), (250 + bar_width, 680), (100, 255, 100), -1)
                cv2.rectangle(img, (250, 650), (650, 680), (255, 255, 255), 2)
            
            # Revenue projection (appears after 2 seconds)
            if frame_num > fps * 2:
                revenue_millions = min(8.5, (frame_num - fps * 2) / fps * 2)
                cv2.putText(img, f"Revenue Projection: ${revenue_millions:.1f}M", (250, 750), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 200, 100), 3)
            
            # Market size (appears after 3 seconds)
            if frame_num > fps * 3:
                market_size = min(250000, int((frame_num - fps * 3) / fps * 125000))
                cv2.putText(img, f"Market Size: {market_size:,} customers", (250, 850), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1.2, (200, 100, 255), 3)
            
            # Call to action (final second)
            if frame_num > fps * 4:
                alpha = min(1.0, (frame_num - fps * 4) / fps)
                color_intensity = int(255 * alpha)
                cv2.putText(img, "Ready to Disrupt the Market?", (400, 950), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1.5, (color_intensity, color_intensity, 255), 4)
            
            # Write frame
            out.write(img)
            
            # Progress indicator
            if frame_num % 30 == 0:
                print(f"   Frame {frame_num}/{total_frames} ({frame_num/total_frames*100:.1f}%)")
        
        out.release()
        print(f"✅ Professional demo video created: {filename}")
        return filename
        
    except ImportError:
        print("⚠️ OpenCV not available, creating simple placeholder")
        return create_simple_placeholder(filename, business_name)
    except Exception as e:
        print(f"⚠️ Video creation error: {e}, creating simple placeholder")
        return create_simple_placeholder(filename, business_name)

def create_simple_placeholder(filename, business_name):
    """Create a simple placeholder when opencv is not available"""
    import base64
    
    # Minimal valid MP4 file
    mp4_data = base64.b64decode("""
    AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAAIZnJlZQAAAAhtZGF0
    """)
    
    with open(filename, 'wb') as f:
        f.write(mp4_data)
    
    print(f"✅ Simple placeholder created: {filename}")
    return filename

if __name__ == "__main__":
    os.makedirs("static/generated", exist_ok=True)
    
    # Create a better demo video
    create_professional_demo_video("static/generated/video_ai_market_validator.mp4", "AI Market Validator", 5)
    
    print("\n🎬 Professional demo video ready!")
    print("The video now includes animated text, progress bars, and business metrics.")
