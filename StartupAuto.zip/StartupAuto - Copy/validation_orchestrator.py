"""
Stage 2: AI-Powered Validation Orchestrator with LlamaIndex
Transforms market opportunities into comprehensive business consulting using knowledge-driven AI agents
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, asdict
from enum import Enum

# LlamaIndex imports (will handle gracefully if not installed)
try:
    from llama_index.core import VectorStoreIndex, Document, Settings
    from llama_index.llms.openai import OpenAI
    from llama_index.embeddings.openai import OpenAIEmbedding
    from llama_index.core.tools import QueryEngineTool, ToolMetadata
    from llama_index.core.agent import ReActAgent
    LLAMAINDEX_AVAILABLE = True
except ImportError:
    LLAMAINDEX_AVAILABLE = False
    print("⚠️ LlamaIndex not available - using fallback validation system")

from config import Config

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ValidationDecision(Enum):
    GO = "GO"
    GO_WITH_CONDITIONS = "GO_WITH_CONDITIONS"
    CAUTION = "CAUTION"
    NO_GO = "NO_GO"

@dataclass
class ValidationResult:
    """Comprehensive validation result from all agents"""
    decision: ValidationDecision
    overall_score: float
    feasibility_score: float
    market_score: float
    financial_score: float
    risk_score: float
    confidence: float
    key_insights: List[str]
    conditions: List[str]
    risk_factors: List[str]
    recommendations: List[str]
    knowledge_sources: List[str]
    detailed_analysis: Dict[str, Any]

class KnowledgeIndexManager:
    """Manages all knowledge indexes for validation domains"""
    
    def __init__(self, openai_api_key: str):
        self.openai_api_key = openai_api_key
        self.indexes = {}
        
        if LLAMAINDEX_AVAILABLE:
            # Configure LlamaIndex settings
            Settings.llm = OpenAI(api_key=openai_api_key, model="gpt-4-turbo")
            Settings.embed_model = OpenAIEmbedding(api_key=openai_api_key)
        
        self._initialize_knowledge_bases()
    
    def _initialize_knowledge_bases(self):
        """Initialize all knowledge indexes"""
        
        # Feasibility Knowledge Base
        feasibility_knowledge = [
            "Simple CRUD applications typically require 2-4 complexity points and 2-6 months development timeline",
            "AI/ML integration adds 6-8 complexity points and requires 50-100% additional timeline",
            "Mobile apps require 4-6 months for MVP, add 3 months for cross-platform",
            "Real-time features like chat or live updates add 2-3 complexity points",
            "Third-party API integrations each add 1-2 complexity points",
            "Payment processing integration requires PCI compliance and adds 2-4 weeks",
            "User authentication systems add 1-2 complexity points",
            "Advanced analytics and reporting features add 3-4 complexity points",
            "Video/audio processing requires specialized infrastructure and 4-6 additional months",
            "Blockchain integration requires 6+ months and specialized expertise",
            "IoT device integration adds hardware complexity and 3-6 months timeline",
            "Enterprise-grade security requirements double development timeline",
            "Scalability for 100K+ users requires cloud architecture planning and adds 2-4 months"
        ]
        
        # Market Knowledge Base
        market_knowledge = [
            "SaaS markets with $1B+ TAM and <10 competitors show high opportunity",
            "Consumer app markets require 10M+ target users for venture scale",
            "B2B markets need $50K+ customer LTV for sustainable unit economics",
            "Highly regulated industries (healthcare, finance) add 6-12 months compliance overhead",
            "Network effect businesses require 2-3 years to reach critical mass",
            "Marketplace models need both sides to launch simultaneously - 2x complexity",
            "Subscription models need <5% monthly churn for sustainable growth",
            "Freemium models require 2-5% conversion rates to paid tiers",
            "Enterprise sales cycles average 6-12 months and require dedicated sales team",
            "Consumer apps need viral coefficient >1.0 for organic growth",
            "AI-powered products need proprietary datasets for sustainable competitive advantage",
            "Developer tools markets require strong community building and 12+ months adoption",
            "E-commerce requires inventory management and adds operational complexity"
        ]
        
        # Financial Knowledge Base  
        financial_knowledge = [
            "SaaS businesses need 3:1 LTV to CAC ratio for venture viability",
            "Consumer apps require <$5 customer acquisition cost for scalability",
            "B2B SaaS should target 20%+ net revenue retention",
            "Marketplaces need 20-30% take rates for sustainable unit economics",
            "Hardware startups require $2M+ initial funding for inventory and manufacturing",
            "AI/ML products need $500K-$2M for compute infrastructure and data acquisition",
            "Mobile apps need $100K-$500K for development and initial marketing",
            "Enterprise software requires 12-18 months runway for sales cycle completion",
            "Subscription businesses should achieve 40%+ gross margins",
            "E-commerce needs 20%+ gross margins after shipping and returns",
            "Freemium models require 95%+ gross margins on free tier",
            "Platform businesses can achieve 60-80% gross margins at scale",
            "Service marketplaces typically operate on 15-25% gross margins"
        ]
        
        # Risk Knowledge Base
        risk_knowledge = [
            "Single founder startups have 70% higher failure rate than co-founder teams",
            "Non-technical founders in tech startups face 50% higher execution risk",
            "Markets with 3+ dominant players require unique differentiation strategy",
            "Regulatory approval requirements add 12-24 months and $1M+ costs",
            "Platform dependency (iOS/Android) creates 30% business risk from policy changes",
            "API dependency on major tech companies creates integration and pricing risks",
            "Winner-take-all markets require massive early investment and perfect execution",
            "Privacy regulations (GDPR, CCPA) add compliance costs and feature limitations",
            "Patent-heavy industries require $500K+ IP protection and legal costs",
            "International expansion requires localization and adds 50-100% development cost",
            "Seasonal businesses face cash flow challenges and 6-month revenue cycles",
            "Hardware products face supply chain risks and 12-18 month development cycles",
            "Two-sided marketplaces face chicken-and-egg problem requiring 18+ months to solve"
        ]
        
        if LLAMAINDEX_AVAILABLE:
            # Create LlamaIndex documents and indexes
            self.indexes['feasibility'] = self._create_index(feasibility_knowledge, "feasibility")
            self.indexes['market'] = self._create_index(market_knowledge, "market")
            self.indexes['financial'] = self._create_index(financial_knowledge, "financial")
            self.indexes['risk'] = self._create_index(risk_knowledge, "risk")
        else:
            # Fallback: Store as simple dictionaries
            self.indexes['feasibility'] = feasibility_knowledge
            self.indexes['market'] = market_knowledge
            self.indexes['financial'] = financial_knowledge
            self.indexes['risk'] = risk_knowledge
    
    def _create_index(self, knowledge_list: List[str], domain: str) -> Any:
        """Create a LlamaIndex VectorStoreIndex from knowledge"""
        documents = [Document(text=knowledge) for knowledge in knowledge_list]
        index = VectorStoreIndex.from_documents(documents)
        return index.as_query_engine()
    
    def query_knowledge(self, domain: str, query: str) -> str:
        """Query a specific knowledge domain"""
        if LLAMAINDEX_AVAILABLE and domain in self.indexes:
            response = self.indexes[domain].query(query)
            return str(response)
        else:
            # Fallback: Simple keyword matching
            knowledge_base = self.indexes.get(domain, [])
            relevant_knowledge = []
            query_lower = query.lower()
            
            for knowledge in knowledge_base:
                if any(word in knowledge.lower() for word in query_lower.split()):
                    relevant_knowledge.append(knowledge)
            
            return " | ".join(relevant_knowledge[:3]) if relevant_knowledge else "No relevant knowledge found"

class ValidationAgent:
    """Base class for all validation agents"""
    
    def __init__(self, knowledge_manager: KnowledgeIndexManager, domain: str):
        self.knowledge_manager = knowledge_manager
        self.domain = domain
    
    async def analyze(self, opportunity_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze the opportunity from this agent's domain perspective"""
        raise NotImplementedError

class FeasibilityAgent(ValidationAgent):
    """Technical feasibility analysis agent"""
    
    def __init__(self, knowledge_manager: KnowledgeIndexManager):
        super().__init__(knowledge_manager, "feasibility")
    
    async def analyze(self, opportunity_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze technical feasibility"""
        
        business_idea = opportunity_data.get('business_idea', '')
        market_data = opportunity_data.get('market_research', {})
        
        # Query knowledge base for feasibility insights
        query = f"Analyze technical feasibility and complexity of: {business_idea}"
        knowledge_response = self.knowledge_manager.query_knowledge("feasibility", query)
        
        # Analyze complexity factors
        complexity_factors = []
        complexity_score = 3.0  # Base score
        
        idea_lower = business_idea.lower()
        
        # AI/ML complexity
        if any(term in idea_lower for term in ['ai', 'artificial intelligence', 'machine learning', 'ml', 'neural']):
            complexity_factors.append("AI/ML integration requires specialized expertise and 6-8 months additional development")
            complexity_score += 2.5
        
        # Mobile complexity
        if any(term in idea_lower for term in ['mobile', 'app', 'ios', 'android']):
            complexity_factors.append("Mobile development requires 4-6 months MVP timeline")
            complexity_score += 1.5
        
        # Real-time features
        if any(term in idea_lower for term in ['real-time', 'live', 'chat', 'streaming']):
            complexity_factors.append("Real-time features require specialized infrastructure")
            complexity_score += 1.0
        
        # Video/audio processing
        if any(term in idea_lower for term in ['video', 'audio', 'multimedia', 'streaming']):
            complexity_factors.append("Video/audio processing requires significant infrastructure investment")
            complexity_score += 2.0
        
        # Calculate feasibility score (0-100, lower complexity = higher feasibility)
        feasibility_score = max(10, 100 - (complexity_score * 8))
        
        # Determine timeline estimate
        base_timeline = 4  # months
        timeline_months = int(base_timeline + (complexity_score - 3) * 1.5)
        
        return {
            "feasibility_score": round(feasibility_score, 1),
            "complexity_score": round(complexity_score, 1),
            "timeline_months": timeline_months,
            "complexity_factors": complexity_factors,
            "knowledge_insights": knowledge_response,
            "recommendations": self._generate_feasibility_recommendations(complexity_score, complexity_factors),
            "technical_requirements": self._identify_technical_requirements(business_idea),
            "risk_mitigation": self._suggest_risk_mitigation(complexity_factors)
        }
    
    def _generate_feasibility_recommendations(self, complexity_score: float, factors: List[str]) -> List[str]:
        """Generate feasibility recommendations"""
        recommendations = []
        
        if complexity_score > 7:
            recommendations.append("🚨 High complexity project - consider MVP approach to validate core value proposition first")
            recommendations.append("🔧 Recommend experienced technical co-founder or CTO hire")
        elif complexity_score > 5:
            recommendations.append("⚠️ Medium complexity - plan for 6-12 month development timeline")
            recommendations.append("👥 Consider hybrid team of contractors and full-time developers")
        else:
            recommendations.append("✅ Feasible with standard web development team")
            recommendations.append("🚀 Good candidate for rapid prototyping and quick market validation")
        
        if any('AI' in factor for factor in factors):
            recommendations.append("🤖 AI features should be built incrementally - start with rule-based logic")
        
        return recommendations
    
    def _identify_technical_requirements(self, business_idea: str) -> List[str]:
        """Identify key technical requirements"""
        requirements = ["Web application framework", "Database design", "User authentication"]
        
        idea_lower = business_idea.lower()
        
        if any(term in idea_lower for term in ['ai', 'ml', 'machine learning']):
            requirements.extend(["ML model training pipeline", "Model serving infrastructure", "Data preprocessing"])
        
        if any(term in idea_lower for term in ['mobile', 'app']):
            requirements.extend(["Mobile app development", "App store deployment", "Push notifications"])
        
        if any(term in idea_lower for term in ['payment', 'subscription', 'billing']):
            requirements.extend(["Payment processing integration", "PCI compliance", "Subscription management"])
        
        return requirements
    
    def _suggest_risk_mitigation(self, factors: List[str]) -> List[str]:
        """Suggest risk mitigation strategies"""
        mitigation = []
        
        if any('AI' in factor for factor in factors):
            mitigation.append("Start with simple ML models and gradually increase complexity")
        
        if any('infrastructure' in factor for factor in factors):
            mitigation.append("Use cloud services to minimize infrastructure management overhead")
        
        mitigation.append("Build comprehensive test suite to ensure quality")
        mitigation.append("Plan for iterative development with regular user feedback")
        
        return mitigation

class MarketAgent(ValidationAgent):
    """Market validation and opportunity analysis agent"""
    
    def __init__(self, knowledge_manager: KnowledgeIndexManager):
        super().__init__(knowledge_manager, "market")
    
    async def analyze(self, opportunity_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze market opportunity and validation"""
        
        business_idea = opportunity_data.get('business_idea', '')
        market_research = opportunity_data.get('market_research', {})
        
        # Query knowledge base for market insights
        query = f"Validate market opportunity for: {business_idea}"
        knowledge_response = self.knowledge_manager.query_knowledge("market", query)
        
        # Extract market data from research
        reddit_data = market_research.get('reddit_analysis', {})
        competitor_data = market_research.get('competitor_analysis', {})
        trends_data = market_research.get('trends_analysis', {})
        
        # Calculate market score components
        market_size_score = self._calculate_market_size_score(reddit_data, trends_data)
        competition_score = self._calculate_competition_score(competitor_data)
        validation_score = self._calculate_validation_score(reddit_data, trends_data)
        
        # Overall market score (weighted average)
        market_score = (
            market_size_score * 0.4 +
            competition_score * 0.3 + 
            validation_score * 0.3
        )
        
        return {
            "market_score": round(market_score, 1),
            "market_size_score": round(market_size_score, 1),
            "competition_score": round(competition_score, 1),
            "validation_score": round(validation_score, 1),
            "target_market": self._define_target_market(business_idea, reddit_data),
            "market_size_estimate": self._estimate_market_size(market_research),
            "competitive_advantage": self._identify_competitive_advantage(competitor_data),
            "market_risks": self._identify_market_risks(competitor_data, trends_data),
            "knowledge_insights": knowledge_response,
            "go_to_market_strategy": self._suggest_gtm_strategy(business_idea, market_research)
        }
    
    def _calculate_market_size_score(self, reddit_data: Dict, trends_data: Dict) -> float:
        """Calculate market size opportunity score"""
        base_score = 50.0
        
        # Reddit market indicators
        estimated_market = reddit_data.get('market_size_indicators', {}).get('estimated_market_size', 0)
        if estimated_market > 1000000:
            base_score += 30
        elif estimated_market > 100000:
            base_score += 20
        elif estimated_market > 10000:
            base_score += 10
        
        # Google Trends demand
        market_demand = trends_data.get('market_demand', 'low')
        if market_demand == 'very_high':
            base_score += 20
        elif market_demand == 'high':
            base_score += 15
        elif market_demand == 'medium':
            base_score += 10
        
        return min(base_score, 100.0)
    
    def _calculate_competition_score(self, competitor_data: Dict) -> float:
        """Calculate competitive landscape score (higher = less competition)"""
        base_score = 50.0
        
        total_competitors = competitor_data.get('total_competitors', 5)
        market_maturity = competitor_data.get('market_maturity', 'unknown')
        
        # Fewer competitors = higher score
        if total_competitors < 3:
            base_score += 30
        elif total_competitors < 8:
            base_score += 20
        elif total_competitors < 15:
            base_score += 10
        else:
            base_score -= 10
        
        # Market maturity factor
        if market_maturity == 'emerging':
            base_score += 20
        elif market_maturity == 'growing':
            base_score += 10
        elif market_maturity == 'mature':
            base_score -= 15
        
        return max(min(base_score, 100.0), 0.0)
    
    def _calculate_validation_score(self, reddit_data: Dict, trends_data: Dict) -> float:
        """Calculate market validation strength"""
        base_score = 30.0
        
        # Reddit validation
        reddit_validation = reddit_data.get('market_validation', {}).get('score', 0)
        base_score += reddit_validation * 0.5
        
        # Trends validation  
        trending_areas = len(trends_data.get('trending_areas', []))
        base_score += min(trending_areas * 5, 20)
        
        return min(base_score, 100.0)
    
    def _define_target_market(self, business_idea: str, reddit_data: Dict) -> str:
        """Define primary target market"""
        idea_lower = business_idea.lower()
        
        if any(term in idea_lower for term in ['b2b', 'business', 'enterprise', 'saas']):
            return "B2B/Enterprise market"
        elif any(term in idea_lower for term in ['consumer', 'personal', 'individual']):
            return "Consumer/B2C market"
        elif any(term in idea_lower for term in ['developer', 'api', 'tool']):
            return "Developer/Technical market"
        else:
            communities = reddit_data.get('market_size_indicators', {}).get('unique_communities', 0)
            if communities > 5:
                return "Multi-segment consumer market"
            else:
                return "Niche/Specialized market"
    
    def _estimate_market_size(self, market_research: Dict) -> str:
        """Estimate total addressable market"""
        reddit_size = market_research.get('reddit_analysis', {}).get('market_size_indicators', {}).get('estimated_market_size', 0)
        
        if reddit_size > 5000000:
            return "$1B+ TAM (Large market opportunity)"
        elif reddit_size > 1000000:
            return "$100M-$1B TAM (Significant market)"
        elif reddit_size > 100000:
            return "$10M-$100M TAM (Niche market)"
        else:
            return "<$10M TAM (Micro market)"
    
    def _identify_competitive_advantage(self, competitor_data: Dict) -> str:
        """Identify potential competitive advantages"""
        market_gaps = competitor_data.get('market_gaps', [])
        
        if market_gaps:
            return f"Market gap opportunity: {market_gaps[0].get('description', 'Unmet user needs')}"
        
        market_maturity = competitor_data.get('market_maturity', 'unknown')
        if market_maturity == 'emerging':
            return "First-mover advantage in emerging market"
        else:
            return "Differentiation through superior user experience and technology"
    
    def _identify_market_risks(self, competitor_data: Dict, trends_data: Dict) -> List[str]:
        """Identify key market risks"""
        risks = []
        
        total_competitors = competitor_data.get('total_competitors', 0)
        if total_competitors > 10:
            risks.append("🚨 Highly competitive market with many established players")
        
        market_maturity = competitor_data.get('market_maturity', 'unknown')
        if market_maturity == 'mature':
            risks.append("⚠️ Mature market may be difficult to penetrate")
        
        market_demand = trends_data.get('market_demand', 'unknown')
        if market_demand in ['low', 'minimal']:
            risks.append("📉 Low market demand may limit growth potential")
        
        if not risks:
            risks.append("✅ Low identified market risks")
        
        return risks
    
    def _suggest_gtm_strategy(self, business_idea: str, market_research: Dict) -> List[str]:
        """Suggest go-to-market strategy"""
        strategy = []
        
        idea_lower = business_idea.lower()
        
        if any(term in idea_lower for term in ['b2b', 'enterprise', 'saas']):
            strategy.extend([
                "🎯 Direct sales approach for enterprise customers",
                "📧 Content marketing and thought leadership",
                "🤝 Partner channel development"
            ])
        elif any(term in idea_lower for term in ['consumer', 'app', 'mobile']):
            strategy.extend([
                "📱 App store optimization and featured placements",
                "📊 Social media marketing and influencer partnerships",
                "🎁 Freemium model for user acquisition"
            ])
        else:
            strategy.extend([
                "🚀 Product-led growth with free trial",
                "👥 Community building and user-generated content",
                "🔗 Strategic partnerships for distribution"
            ])
        
        # Add validation-based recommendations
        reddit_threads = market_research.get('reddit_analysis', {}).get('total_threads', 0)
        if reddit_threads > 30:
            strategy.append("💬 Leverage Reddit communities for early adoption")
        
        return strategy

class FinancialAgent(ValidationAgent):
    """Financial viability and business model analysis agent"""
    
    def __init__(self, knowledge_manager: KnowledgeIndexManager):
        super().__init__(knowledge_manager, "financial")
    
    async def analyze(self, opportunity_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze financial viability and business model"""
        
        business_idea = opportunity_data.get('business_idea', '')
        market_research = opportunity_data.get('market_research', {})
        
        # Query knowledge base for financial insights
        query = f"Analyze financial viability and business model for: {business_idea}"
        knowledge_response = self.knowledge_manager.query_knowledge("financial", query)
        
        # Determine business model
        business_model = self._identify_business_model(business_idea)
        
        # Calculate financial metrics
        revenue_projection = self._project_revenue(business_idea, market_research)
        cost_structure = self._estimate_costs(business_idea)
        funding_requirements = self._estimate_funding_needs(business_idea, cost_structure)
        
        # Calculate financial score
        financial_score = self._calculate_financial_score(revenue_projection, cost_structure, business_model)
        
        return {
            "financial_score": round(financial_score, 1),
            "business_model": business_model,
            "revenue_projection": revenue_projection,
            "cost_structure": cost_structure,
            "funding_requirements": funding_requirements,
            "unit_economics": self._calculate_unit_economics(business_model, revenue_projection),
            "monetization_strategy": self._suggest_monetization_strategy(business_idea),
            "financial_risks": self._identify_financial_risks(business_model, cost_structure),
            "knowledge_insights": knowledge_response,
            "path_to_profitability": self._analyze_profitability_path(revenue_projection, cost_structure)
        }
    
    def _identify_business_model(self, business_idea: str) -> str:
        """Identify the most likely business model"""
        idea_lower = business_idea.lower()
        
        if any(term in idea_lower for term in ['subscription', 'saas', 'monthly', 'annual']):
            return "SaaS/Subscription"
        elif any(term in idea_lower for term in ['marketplace', 'platform', 'connect']):
            return "Marketplace/Platform"
        elif any(term in idea_lower for term in ['advertising', 'ads', 'sponsored']):
            return "Advertising/Media"
        elif any(term in idea_lower for term in ['transaction', 'payment', 'fee']):
            return "Transaction-based"
        elif any(term in idea_lower for term in ['freemium', 'premium', 'upgrade']):
            return "Freemium"
        else:
            return "Direct Sales/One-time"
    
    def _project_revenue(self, business_idea: str, market_research: Dict) -> Dict[str, Any]:
        """Project revenue potential"""
        
        # Base market size from research
        market_size = market_research.get('synthesis', {}).get('market_size', 100000)
        
        # Business model factors
        business_model = self._identify_business_model(business_idea)
        
        if business_model == "SaaS/Subscription":
            # SaaS model projections
            target_users_y1 = min(market_size * 0.001, 10000)  # 0.1% market penetration
            target_users_y3 = min(market_size * 0.01, 100000)  # 1% market penetration
            avg_monthly_price = 50  # Estimate
            
            return {
                "model": "SaaS/Subscription",
                "year_1_arr": int(target_users_y1 * avg_monthly_price * 12),
                "year_3_arr": int(target_users_y3 * avg_monthly_price * 12),
                "pricing_estimate": f"${avg_monthly_price}/month per user",
                "user_projections": {
                    "year_1": int(target_users_y1),
                    "year_3": int(target_users_y3)
                }
            }
        
        elif business_model == "Marketplace/Platform":
            # Marketplace model projections
            transaction_volume_y1 = min(market_size * 100, 10000000)  # $100 per user
            transaction_volume_y3 = min(market_size * 500, 100000000)  # $500 per user
            take_rate = 0.15  # 15% take rate
            
            return {
                "model": "Marketplace/Platform",
                "year_1_revenue": int(transaction_volume_y1 * take_rate),
                "year_3_revenue": int(transaction_volume_y3 * take_rate),
                "take_rate": f"{take_rate*100}%",
                "transaction_projections": {
                    "year_1": f"${transaction_volume_y1:,.0f}",
                    "year_3": f"${transaction_volume_y3:,.0f}"
                }
            }
        
        else:
            # Generic projection
            customers_y1 = min(market_size * 0.005, 5000)  # 0.5% market penetration
            customers_y3 = min(market_size * 0.02, 50000)  # 2% market penetration
            avg_price = 200  # Estimate
            
            return {
                "model": business_model,
                "year_1_revenue": int(customers_y1 * avg_price),
                "year_3_revenue": int(customers_y3 * avg_price),
                "pricing_estimate": f"${avg_price} average price",
                "customer_projections": {
                    "year_1": int(customers_y1),
                    "year_3": int(customers_y3)
                }
            }
    
    def _estimate_costs(self, business_idea: str) -> Dict[str, Any]:
        """Estimate cost structure"""
        
        idea_lower = business_idea.lower()
        
        # Base costs
        base_costs = {
            "development": 150000,  # Initial development
            "team_annual": 300000,  # 2-3 person team
            "infrastructure": 12000,  # Annual hosting/tools
            "marketing": 60000,  # Annual marketing budget
            "operations": 30000  # Annual operations
        }
        
        # Adjust based on complexity
        if any(term in idea_lower for term in ['ai', 'ml', 'machine learning']):
            base_costs["development"] += 100000  # AI complexity
            base_costs["infrastructure"] += 24000  # Additional compute
            base_costs["team_annual"] += 100000  # AI expertise
        
        if any(term in idea_lower for term in ['mobile', 'app']):
            base_costs["development"] += 50000  # Mobile development
            base_costs["marketing"] += 40000  # App store marketing
        
        if any(term in idea_lower for term in ['video', 'audio', 'streaming']):
            base_costs["infrastructure"] += 60000  # Media infrastructure
            base_costs["development"] += 75000  # Media processing
        
        # Calculate totals
        total_initial = base_costs["development"]
        total_annual = sum(cost for key, cost in base_costs.items() if key != "development")
        
        return {
            "initial_investment": total_initial,
            "annual_operating_cost": total_annual,
            "monthly_burn_rate": total_annual // 12,
            "cost_breakdown": base_costs,
            "cost_per_category": {
                "Product Development": base_costs["development"],
                "Team & Salaries": base_costs["team_annual"],
                "Technology & Infrastructure": base_costs["infrastructure"],
                "Marketing & Sales": base_costs["marketing"],
                "Operations & Legal": base_costs["operations"]
            }
        }
    
    def _estimate_funding_needs(self, business_idea: str, cost_structure: Dict) -> Dict[str, Any]:
        """Estimate funding requirements"""
        
        initial_investment = cost_structure["initial_investment"]
        monthly_burn = cost_structure["monthly_burn_rate"]
        
        # 18-month runway is standard
        runway_months = 18
        total_needed = initial_investment + (monthly_burn * runway_months)
        
        # Determine funding stage
        if total_needed < 250000:
            stage = "Pre-seed/Bootstrap"
            funding_sources = ["Personal savings", "Friends & family", "Angel investors"]
        elif total_needed < 1000000:
            stage = "Seed funding"
            funding_sources = ["Angel investors", "Micro VCs", "Seed funds"]
        else:
            stage = "Series A"
            funding_sources = ["Venture capital", "Strategic investors"]
        
        return {
            "total_funding_needed": total_needed,
            "funding_stage": stage,
            "runway_months": runway_months,
            "funding_sources": funding_sources,
            "use_of_funds": {
                "Product Development": f"${initial_investment:,.0f} ({initial_investment/total_needed*100:.0f}%)",
                "Operations (18mo)": f"${monthly_burn*runway_months:,.0f} ({monthly_burn*runway_months/total_needed*100:.0f}%)"
            }
        }
    
    def _calculate_financial_score(self, revenue_proj: Dict, cost_structure: Dict, business_model: str) -> float:
        """Calculate overall financial viability score"""
        
        # Extract year 1 revenue (handle different model structures)
        if "year_1_arr" in revenue_proj:
            year_1_revenue = revenue_proj["year_1_arr"]
        elif "year_1_revenue" in revenue_proj:
            year_1_revenue = revenue_proj["year_1_revenue"]
        else:
            year_1_revenue = 100000  # Default
        
        annual_costs = cost_structure["annual_operating_cost"]
        
        # Revenue to cost ratio
        revenue_ratio = year_1_revenue / max(annual_costs, 1)
        
        # Base score from business model
        model_scores = {
            "SaaS/Subscription": 80,
            "Marketplace/Platform": 75,
            "Freemium": 70,
            "Transaction-based": 65,
            "Advertising/Media": 60,
            "Direct Sales/One-time": 55
        }
        
        base_score = model_scores.get(business_model, 60)
        
        # Adjust based on revenue potential
        if revenue_ratio > 2.0:
            base_score += 15  # Strong revenue potential
        elif revenue_ratio > 1.0:
            base_score += 10  # Decent revenue potential
        elif revenue_ratio > 0.5:
            base_score += 5   # Moderate revenue potential
        else:
            base_score -= 10  # Weak revenue potential
        
        return max(min(base_score, 100.0), 0.0)
    
    def _calculate_unit_economics(self, business_model: str, revenue_proj: Dict) -> Dict[str, Any]:
        """Calculate unit economics"""
        
        if business_model == "SaaS/Subscription":
            monthly_price = 50  # Estimate from earlier
            cac = 150  # Customer acquisition cost estimate
            ltv = monthly_price * 24  # 24 month average lifetime
            
            return {
                "customer_acquisition_cost": cac,
                "lifetime_value": ltv,
                "ltv_cac_ratio": round(ltv / cac, 2),
                "payback_period_months": round(cac / monthly_price, 1),
                "monthly_churn_estimate": "4%"
            }
        
        elif business_model == "Marketplace/Platform":
            avg_transaction = 200  # Estimate
            take_rate = 0.15
            revenue_per_transaction = avg_transaction * take_rate
            
            return {
                "revenue_per_transaction": revenue_per_transaction,
                "transaction_cost": 5,  # Processing cost
                "contribution_margin": revenue_per_transaction - 5,
                "transactions_to_break_even": 1000
            }
        
        else:
            return {
                "model": business_model,
                "note": "Unit economics vary significantly by specific implementation"
            }
    
    def _suggest_monetization_strategy(self, business_idea: str) -> List[str]:
        """Suggest monetization strategies"""
        
        strategies = []
        idea_lower = business_idea.lower()
        
        if any(term in idea_lower for term in ['b2b', 'business', 'enterprise']):
            strategies.extend([
                "💰 Tiered subscription pricing (Basic/Pro/Enterprise)",
                "📊 Usage-based pricing for advanced features",
                "🤝 Enterprise contracts with annual commitments"
            ])
        
        elif any(term in idea_lower for term in ['marketplace', 'platform']):
            strategies.extend([
                "💸 Transaction fees (10-20% of transaction value)",
                "📈 Subscription fees for premium seller features",
                "🎯 Lead generation fees for service providers"
            ])
        
        elif any(term in idea_lower for term in ['consumer', 'app', 'personal']):
            strategies.extend([
                "🆓 Freemium model with premium upgrade",
                "📱 In-app purchases for additional features",
                "📊 Subscription for unlimited usage"
            ])
        
        else:
            strategies.extend([
                "💳 Direct purchase or licensing fees",
                "🔄 Recurring subscription for ongoing value",
                "🎯 Performance-based pricing model"
            ])
        
        return strategies
    
    def _identify_financial_risks(self, business_model: str, cost_structure: Dict) -> List[str]:
        """Identify key financial risks"""
        
        risks = []
        monthly_burn = cost_structure["monthly_burn_rate"]
        
        if monthly_burn > 50000:
            risks.append("🔥 High burn rate requires significant funding runway")
        
        if business_model == "Marketplace/Platform":
            risks.append("🐔 Chicken-and-egg problem may delay revenue generation")
        
        if business_model == "Advertising/Media":
            risks.append("📺 Ad-dependent revenue vulnerable to market fluctuations")
        
        if business_model == "Freemium":
            risks.append("🆓 Low conversion rates could impact revenue projections")
        
        if not risks:
            risks.append("✅ Standard financial risks for early-stage startups")
        
        return risks
    
    def _analyze_profitability_path(self, revenue_proj: Dict, cost_structure: Dict) -> Dict[str, Any]:
        """Analyze path to profitability"""
        
        # Extract year 3 revenue
        if "year_3_arr" in revenue_proj:
            year_3_revenue = revenue_proj["year_3_arr"]
        elif "year_3_revenue" in revenue_proj:
            year_3_revenue = revenue_proj["year_3_revenue"]
        else:
            year_3_revenue = 500000  # Default
        
        annual_costs = cost_structure["annual_operating_cost"]
        
        # Estimate when break-even occurs
        if year_3_revenue > annual_costs:
            break_even_year = 2.5  # Estimate between year 2-3
            profitability_outlook = "Strong path to profitability"
        elif year_3_revenue > annual_costs * 0.7:
            break_even_year = 3.5
            profitability_outlook = "Moderate path to profitability"
        else:
            break_even_year = 4.0
            profitability_outlook = "Extended path to profitability"
        
        return {
            "break_even_year_estimate": break_even_year,
            "profitability_outlook": profitability_outlook,
            "year_3_profit_margin": f"{((year_3_revenue - annual_costs) / year_3_revenue * 100):.1f}%"
        }

class RiskAgent(ValidationAgent):
    """Risk assessment and mitigation analysis agent"""
    
    def __init__(self, knowledge_manager: KnowledgeIndexManager):
        super().__init__(knowledge_manager, "risk")
    
    async def analyze(self, opportunity_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze risks and mitigation strategies"""
        
        business_idea = opportunity_data.get('business_idea', '')
        market_research = opportunity_data.get('market_research', {})
        
        # Query knowledge base for risk insights
        query = f"Identify risks and challenges for: {business_idea}"
        knowledge_response = self.knowledge_manager.query_knowledge("risk", query)
        
        # Analyze different risk categories
        execution_risks = self._analyze_execution_risks(business_idea)
        market_risks = self._analyze_market_risks(market_research)
        competitive_risks = self._analyze_competitive_risks(market_research.get('competitor_analysis', {}))
        technical_risks = self._analyze_technical_risks(business_idea)
        regulatory_risks = self._analyze_regulatory_risks(business_idea)
        
        # Calculate overall risk score (0-100, lower is better)
        risk_score = self._calculate_risk_score(execution_risks, market_risks, competitive_risks, technical_risks, regulatory_risks)
        
        # Generate mitigation strategies
        mitigation_strategies = self._generate_mitigation_strategies(execution_risks, market_risks, competitive_risks, technical_risks, regulatory_risks)
        
        return {
            "risk_score": round(risk_score, 1),
            "risk_level": self._determine_risk_level(risk_score),
            "execution_risks": execution_risks,
            "market_risks": market_risks,
            "competitive_risks": competitive_risks,
            "technical_risks": technical_risks,
            "regulatory_risks": regulatory_risks,
            "mitigation_strategies": mitigation_strategies,
            "knowledge_insights": knowledge_response,
            "risk_monitoring": self._suggest_risk_monitoring(business_idea),
            "contingency_plans": self._suggest_contingency_plans(business_idea)
        }
    
    def _analyze_execution_risks(self, business_idea: str) -> List[Dict[str, Any]]:
        """Analyze execution and team risks"""
        risks = []
        
        # Default execution risks for startups
        risks.append({
            "risk": "Team composition and experience gaps",
            "severity": "Medium",
            "probability": "High",
            "description": "Early-stage teams often lack key expertise areas"
        })
        
        idea_lower = business_idea.lower()
        
        if any(term in idea_lower for term in ['ai', 'ml', 'machine learning']):
            risks.append({
                "risk": "AI/ML expertise scarcity",
                "severity": "High",
                "probability": "High", 
                "description": "Difficulty hiring qualified AI engineers and data scientists"
            })
        
        if any(term in idea_lower for term in ['marketplace', 'platform', 'network']):
            risks.append({
                "risk": "Two-sided market chicken-and-egg problem",
                "severity": "High",
                "probability": "Medium",
                "description": "Difficulty attracting both sides of marketplace simultaneously"
            })
        
        if any(term in idea_lower for term in ['hardware', 'device', 'iot']):
            risks.append({
                "risk": "Hardware development complexity",
                "severity": "High",
                "probability": "Medium",
                "description": "Manufacturing, supply chain, and quality control challenges"
            })
        
        return risks
    
    def _analyze_market_risks(self, market_research: Dict) -> List[Dict[str, Any]]:
        """Analyze market-related risks"""
        risks = []
        
        # Extract market data
        reddit_data = market_research.get('reddit_analysis', {})
        trends_data = market_research.get('trends_analysis', {})
        
        # Market validation risk
        validation_score = reddit_data.get('market_validation', {}).get('score', 0)
        if validation_score < 50:
            risks.append({
                "risk": "Weak market validation",
                "severity": "High",
                "probability": "Medium",
                "description": f"Market validation score of {validation_score}/100 indicates uncertain demand"
            })
        
        # Market demand risk
        market_demand = trends_data.get('market_demand', 'unknown')
        if market_demand in ['low', 'minimal']:
            risks.append({
                "risk": "Low market demand",
                "severity": "High",
                "probability": "High",
                "description": "Search trends indicate limited market interest"
            })
        
        # Market size risk
        market_size = reddit_data.get('market_size_indicators', {}).get('estimated_market_size', 0)
        if market_size < 100000:
            risks.append({
                "risk": "Limited market size",
                "severity": "Medium",
                "probability": "Medium",
                "description": "Small addressable market may limit growth potential"
            })
        
        return risks
    
    def _analyze_competitive_risks(self, competitor_data: Dict) -> List[Dict[str, Any]]:
        """Analyze competitive landscape risks"""
        risks = []
        
        total_competitors = competitor_data.get('total_competitors', 0)
        market_maturity = competitor_data.get('market_maturity', 'unknown')
        
        # High competition risk
        if total_competitors > 10:
            risks.append({
                "risk": "Intense competition",
                "severity": "High",
                "probability": "High",
                "description": f"{total_competitors} competitors create challenging competitive environment"
            })
        
        # Market maturity risk
        if market_maturity == 'mature':
            risks.append({
                "risk": "Mature market challenges",
                "severity": "Medium",
                "probability": "High",
                "description": "Established players with strong market position and customer loyalty"
            })
        
        # Market gaps analysis
        market_gaps = competitor_data.get('market_gaps', [])
        if len(market_gaps) == 0:
            risks.append({
                "risk": "No clear differentiation opportunity",
                "severity": "High",
                "probability": "Medium",
                "description": "Limited market gaps make differentiation challenging"
            })
        
        return risks
    
    def _analyze_technical_risks(self, business_idea: str) -> List[Dict[str, Any]]:
        """Analyze technical implementation risks"""
        risks = []
        
        idea_lower = business_idea.lower()
        
        # AI/ML technical risks
        if any(term in idea_lower for term in ['ai', 'artificial intelligence', 'machine learning']):
            risks.extend([
                {
                    "risk": "Model accuracy and reliability",
                    "severity": "High",
                    "probability": "Medium",
                    "description": "AI models may not achieve required accuracy for production use"
                },
                {
                    "risk": "Data quality and availability",
                    "severity": "Medium",
                    "probability": "High",
                    "description": "Insufficient or poor quality training data"
                }
            ])
        
        # Real-time processing risks
        if any(term in idea_lower for term in ['real-time', 'live', 'streaming']):
            risks.append({
                "risk": "Scalability and performance",
                "severity": "Medium",
                "probability": "Medium",
                "description": "Real-time systems require robust infrastructure and can be expensive to scale"
            })
        
        # Mobile development risks
        if any(term in idea_lower for term in ['mobile', 'app', 'ios', 'android']):
            risks.append({
                "risk": "Platform dependency and app store policies",
                "severity": "Medium",
                "probability": "Medium",
                "description": "Dependence on app store approval and changing platform policies"
            })
        
        # Integration complexity
        if any(term in idea_lower for term in ['integration', 'api', 'platform']):
            risks.append({
                "risk": "Third-party API dependencies",
                "severity": "Medium",
                "probability": "High",
                "description": "Risk of API changes, rate limits, or service discontinuation"
            })
        
        return risks
    
    def _analyze_regulatory_risks(self, business_idea: str) -> List[Dict[str, Any]]:
        """Analyze regulatory and compliance risks"""
        risks = []
        
        idea_lower = business_idea.lower()
        
        # Privacy and data protection
        if any(term in idea_lower for term in ['data', 'personal', 'user', 'analytics']):
            risks.append({
                "risk": "Data privacy regulations (GDPR, CCPA)",
                "severity": "Medium",
                "probability": "High",
                "description": "Compliance with data protection laws requires ongoing effort and costs"
            })
        
        # Financial services
        if any(term in idea_lower for term in ['payment', 'financial', 'money', 'transaction']):
            risks.append({
                "risk": "Financial services regulations",
                "severity": "High",
                "probability": "High",
                "description": "Complex compliance requirements and licensing for financial products"
            })
        
        # Healthcare
        if any(term in idea_lower for term in ['health', 'medical', 'patient', 'clinical']):
            risks.append({
                "risk": "Healthcare regulations (HIPAA, FDA)",
                "severity": "High",
                "probability": "High",
                "description": "Strict compliance requirements for health-related products"
            })
        
        # AI regulations
        if any(term in idea_lower for term in ['ai', 'artificial intelligence', 'automated']):
            risks.append({
                "risk": "Emerging AI regulations",
                "severity": "Medium",
                "probability": "Medium",
                "description": "Evolving AI governance and ethical requirements"
            })
        
        return risks
    
    def _calculate_risk_score(self, execution_risks: List, market_risks: List, competitive_risks: List, technical_risks: List, regulatory_risks: List) -> float:
        """Calculate overall risk score"""
        
        # Count risks by severity
        all_risks = execution_risks + market_risks + competitive_risks + technical_risks + regulatory_risks
        
        high_severity = len([r for r in all_risks if r.get('severity') == 'High'])
        medium_severity = len([r for r in all_risks if r.get('severity') == 'Medium'])
        low_severity = len([r for r in all_risks if r.get('severity') == 'Low'])
        
        # Calculate weighted risk score (0-100, higher = more risky)
        risk_score = (high_severity * 20) + (medium_severity * 10) + (low_severity * 5)
        
        # Cap at 100
        return min(risk_score, 100.0)
    
    def _determine_risk_level(self, risk_score: float) -> str:
        """Determine overall risk level"""
        if risk_score >= 70:
            return "High Risk"
        elif risk_score >= 40:
            return "Medium Risk"
        else:
            return "Low Risk"
    
    def _generate_mitigation_strategies(self, execution_risks: List, market_risks: List, competitive_risks: List, technical_risks: List, regulatory_risks: List) -> List[str]:
        """Generate risk mitigation strategies"""
        strategies = []
        
        # Execution risk mitigation
        if execution_risks:
            strategies.extend([
                "👥 Build advisory board with domain expertise",
                "🎯 Focus on MVP to validate core assumptions quickly",
                "💰 Secure 18+ month funding runway for execution flexibility"
            ])
        
        # Market risk mitigation
        if market_risks:
            strategies.extend([
                "📊 Conduct continuous market validation through user interviews",
                "🔄 Implement rapid iteration based on user feedback",
                "📈 Monitor market metrics and pivot if necessary"
            ])
        
        # Competitive risk mitigation
        if competitive_risks:
            strategies.extend([
                "🎯 Focus on specific niche or underserved segment",
                "⚡ Prioritize speed to market and rapid feature development",
                "🤝 Build strategic partnerships for competitive advantage"
            ])
        
        # Technical risk mitigation
        if technical_risks:
            strategies.extend([
                "🛠️ Start with simpler technical approach and iterate",
                "☁️ Use proven technologies and cloud services",
                "🧪 Implement comprehensive testing and monitoring"
            ])
        
        # Regulatory risk mitigation
        if regulatory_risks:
            strategies.extend([
                "⚖️ Engage legal counsel early for compliance planning",
                "📋 Build compliance requirements into product development",
                "🏢 Consider regulatory sandboxes for testing"
            ])
        
        return strategies
    
    def _suggest_risk_monitoring(self, business_idea: str) -> List[str]:
        """Suggest ongoing risk monitoring activities"""
        monitoring = [
            "📊 Weekly user feedback and satisfaction surveys",
            "💰 Monthly financial metrics and burn rate tracking",
            "🏆 Quarterly competitive landscape analysis",
            "🎯 Regular customer development interviews"
        ]
        
        idea_lower = business_idea.lower()
        
        if any(term in idea_lower for term in ['ai', 'ml']):
            monitoring.append("🤖 Continuous model performance monitoring")
        
        if any(term in idea_lower for term in ['marketplace', 'platform']):
            monitoring.append("⚖️ Monitor supply/demand balance on platform")
        
        return monitoring
    
    def _suggest_contingency_plans(self, business_idea: str) -> List[str]:
        """Suggest contingency plans for major risks"""
        plans = [
            "💡 Pivot strategy if market validation fails",
            "🏃‍♂️ Rapid cost reduction plan if funding is delayed",
            "🤝 Partnership acquisition strategy if competition intensifies",
            "🛠️ Technology simplification roadmap for faster time-to-market"
        ]
        
        idea_lower = business_idea.lower()
        
        if any(term in idea_lower for term in ['b2b', 'enterprise']):
            plans.append("📞 Direct sales pivot if initial GTM strategy fails")
        
        if any(term in idea_lower for term in ['consumer', 'app']):
            plans.append("📱 Platform diversification beyond primary app stores")
        
        return plans

class ValidationOrchestrator:
    """
    Main orchestrator that coordinates all validation agents using ReAct methodology
    Transforms market opportunities into comprehensive business consulting decisions
    """
    
    def __init__(self, openai_api_key: str):
        self.openai_api_key = openai_api_key
        
        # Initialize knowledge manager
        self.knowledge_manager = KnowledgeIndexManager(openai_api_key)
        
        # Initialize validation agents
        self.feasibility_agent = FeasibilityAgent(self.knowledge_manager)
        self.market_agent = MarketAgent(self.knowledge_manager)
        self.financial_agent = FinancialAgent(self.knowledge_manager)
        self.risk_agent = RiskAgent(self.knowledge_manager)
        
        # Initialize ReAct agent if LlamaIndex is available
        if LLAMAINDEX_AVAILABLE:
            self._initialize_react_agent()
        
        logger.info("🎯 Validation Orchestrator initialized with knowledge-driven agents")
    
    def _initialize_react_agent(self):
        """Initialize ReAct agent for synthesis"""
        try:
            # Create tools for each validation domain
            tools = [
                QueryEngineTool(
                    query_engine=self.knowledge_manager.indexes['feasibility'],
                    metadata=ToolMetadata(
                        name="feasibility_analyzer",
                        description="Analyze technical feasibility, complexity, and development requirements"
                    )
                ),
                QueryEngineTool(
                    query_engine=self.knowledge_manager.indexes['market'],
                    metadata=ToolMetadata(
                        name="market_validator", 
                        description="Validate market opportunity, competition, and demand"
                    )
                ),
                QueryEngineTool(
                    query_engine=self.knowledge_manager.indexes['financial'],
                    metadata=ToolMetadata(
                        name="financial_analyzer",
                        description="Analyze business model, revenue potential, and financial viability"
                    )
                ),
                QueryEngineTool(
                    query_engine=self.knowledge_manager.indexes['risk'],
                    metadata=ToolMetadata(
                        name="risk_assessor",
                        description="Identify risks, challenges, and mitigation strategies"
                    )
                )
            ]
            
            # Create ReAct agent
            self.react_agent = ReActAgent.from_tools(
                tools=tools,
                llm=Settings.llm,
                verbose=True
            )
            
            logger.info("✅ ReAct synthesis agent initialized with knowledge tools")
            
        except Exception as e:
            logger.warning(f"⚠️ Could not initialize ReAct agent: {e}")
            self.react_agent = None
    
    async def validate_opportunity(self, opportunity_data: Dict[str, Any]) -> ValidationResult:
        """
        Main validation method - coordinates all agents and synthesizes results
        
        Args:
            opportunity_data: Dict containing business_idea and market_research data
            
        Returns:
            ValidationResult with comprehensive analysis and decision
        """
        
        business_idea = opportunity_data.get('business_idea', '')
        logger.info(f"🎯 Starting knowledge-driven validation for: {business_idea[:100]}...")
        
        try:
            # Step 1: Run all validation agents in parallel
            logger.info("🔄 Running specialized validation agents...")
            
            feasibility_task = self.feasibility_agent.analyze(opportunity_data)
            market_task = self.market_agent.analyze(opportunity_data)
            financial_task = self.financial_agent.analyze(opportunity_data)
            risk_task = self.risk_agent.analyze(opportunity_data)
            
            # Wait for all agents to complete
            feasibility_result, market_result, financial_result, risk_result = await asyncio.gather(
                feasibility_task, market_task, financial_task, risk_task
            )
            
            logger.info("✅ All validation agents completed analysis")
            
            # Step 2: Synthesize results using ReAct agent or fallback
            if self.react_agent and LLAMAINDEX_AVAILABLE:
                synthesis_result = await self._synthesize_with_react_agent(
                    opportunity_data, feasibility_result, market_result, financial_result, risk_result
                )
            else:
                synthesis_result = await self._synthesize_with_fallback(
                    opportunity_data, feasibility_result, market_result, financial_result, risk_result
                )
            
            # Step 3: Create final validation result
            validation_result = ValidationResult(
                decision=synthesis_result['decision'],
                overall_score=synthesis_result['overall_score'],
                feasibility_score=feasibility_result['feasibility_score'],
                market_score=market_result['market_score'],
                financial_score=financial_result['financial_score'],
                risk_score=risk_result['risk_score'],
                confidence=synthesis_result['confidence'],
                key_insights=synthesis_result['key_insights'],
                conditions=synthesis_result['conditions'],
                risk_factors=synthesis_result['risk_factors'],
                recommendations=synthesis_result['recommendations'],
                knowledge_sources=synthesis_result['knowledge_sources'],
                detailed_analysis={
                    'feasibility': feasibility_result,
                    'market': market_result,
                    'financial': financial_result,
                    'risk': risk_result,
                    'synthesis': synthesis_result
                }
            )
            
            logger.info(f"🎉 Validation complete! Decision: {validation_result.decision.value} (Score: {validation_result.overall_score}/100)")
            
            return validation_result
            
        except Exception as e:
            logger.error(f"❌ Validation failed: {str(e)}")
            # Return a minimal error result
            return ValidationResult(
                decision=ValidationDecision.NO_GO,
                overall_score=0.0,
                feasibility_score=0.0,
                market_score=0.0,
                financial_score=0.0,
                risk_score=100.0,
                confidence=0.0,
                key_insights=[f"Validation failed: {str(e)}"],
                conditions=[],
                risk_factors=["System error during validation"],
                recommendations=["Retry validation or contact support"],
                knowledge_sources=[],
                detailed_analysis={"error": str(e)}
            )
    
    async def _synthesize_with_react_agent(self, opportunity_data: Dict, feasibility: Dict, market: Dict, financial: Dict, risk: Dict) -> Dict[str, Any]:
        """Synthesize results using ReAct agent for intelligent reasoning"""
        
        business_idea = opportunity_data.get('business_idea', '')
        
        # Create comprehensive synthesis prompt
        synthesis_prompt = f"""
        As a senior business consultant, analyze this opportunity and make a GO/NO-GO decision:
        
        BUSINESS IDEA: {business_idea}
        
        AGENT ANALYSIS RESULTS:
        
        Feasibility Analysis:
        - Score: {feasibility['feasibility_score']}/100
        - Timeline: {feasibility['timeline_months']} months
        - Complexity: {feasibility['complexity_score']}/10
        - Key factors: {feasibility['complexity_factors']}
        
        Market Analysis:
        - Score: {market['market_score']}/100
        - Market size: {market['market_size_estimate']}
        - Competition: {market['competition_score']}/100
        - Competitive advantage: {market['competitive_advantage']}
        
        Financial Analysis:
        - Score: {financial['financial_score']}/100
        - Business model: {financial['business_model']}
        - Funding needed: ${financial['funding_requirements']['total_funding_needed']:,.0f}
        - Break-even: {financial['path_to_profitability']['profitability_outlook']}
        
        Risk Analysis:
        - Risk score: {risk['risk_score']}/100 (lower is better)
        - Risk level: {risk['risk_level']}
        - Major risks: {len(risk['execution_risks'] + risk['market_risks'] + risk['competitive_risks'])} identified
        
        DECISION FRAMEWORK:
        - GO: All scores >70, low risks, clear path to market
        - GO_WITH_CONDITIONS: Mixed scores 50-70, manageable risks, needs specific conditions
        - CAUTION: Some scores <50, significant risks, major challenges
        - NO_GO: Multiple scores <40, high risks, fundamental problems
        
        Provide your analysis and decision with specific reasoning based on the knowledge base insights.
        """
        
        try:
            # Use ReAct agent to synthesize with access to knowledge tools
            response = self.react_agent.chat(synthesis_prompt)
            synthesis_text = str(response)
            
            # Parse the ReAct agent response and extract decision
            decision, overall_score, confidence = self._parse_react_response(synthesis_text, feasibility, market, financial, risk)
            
            return {
                "decision": decision,
                "overall_score": overall_score,
                "confidence": confidence,
                "key_insights": self._extract_key_insights(feasibility, market, financial, risk),
                "conditions": self._extract_conditions(decision, feasibility, market, financial, risk),
                "risk_factors": self._extract_top_risks(risk),
                "recommendations": self._generate_recommendations(decision, feasibility, market, financial, risk),
                "knowledge_sources": ["ReAct agent synthesis with domain knowledge"],
                "synthesis_reasoning": synthesis_text
            }
            
        except Exception as e:
            logger.warning(f"ReAct synthesis failed: {e}, using fallback")
            return await self._synthesize_with_fallback(opportunity_data, feasibility, market, financial, risk)
    
    async def _synthesize_with_fallback(self, opportunity_data: Dict, feasibility: Dict, market: Dict, financial: Dict, risk: Dict) -> Dict[str, Any]:
        """Fallback synthesis using simple scoring logic"""
        
        # Calculate overall score (weighted average)
        overall_score = (
            feasibility['feasibility_score'] * 0.25 +
            market['market_score'] * 0.30 +
            financial['financial_score'] * 0.25 +
            max(0, 100 - risk['risk_score']) * 0.20  # Invert risk score
        )
        
        # Determine decision based on score thresholds
        if overall_score >= 75 and risk['risk_score'] < 50:
            decision = ValidationDecision.GO
            confidence = 0.85
        elif overall_score >= 60 and risk['risk_score'] < 70:
            decision = ValidationDecision.GO_WITH_CONDITIONS
            confidence = 0.70
        elif overall_score >= 40:
            decision = ValidationDecision.CAUTION
            confidence = 0.60
        else:
            decision = ValidationDecision.NO_GO
            confidence = 0.50
        
        return {
            "decision": decision,
            "overall_score": round(overall_score, 1),
            "confidence": confidence,
            "key_insights": self._extract_key_insights(feasibility, market, financial, risk),
            "conditions": self._extract_conditions(decision, feasibility, market, financial, risk),
            "risk_factors": self._extract_top_risks(risk),
            "recommendations": self._generate_recommendations(decision, feasibility, market, financial, risk),
            "knowledge_sources": ["Fallback synthesis algorithm"],
            "synthesis_reasoning": f"Score-based decision: {overall_score:.1f}/100 overall score"
        }
    
    def _parse_react_response(self, response_text: str, feasibility: Dict, market: Dict, financial: Dict, risk: Dict) -> tuple:
        """Parse ReAct agent response to extract decision and scores"""
        
        response_lower = response_text.lower()
        
        # Extract decision
        if "no-go" in response_lower or "no_go" in response_lower:
            decision = ValidationDecision.NO_GO
        elif "caution" in response_lower:
            decision = ValidationDecision.CAUTION
        elif "go with conditions" in response_lower or "go_with_conditions" in response_lower:
            decision = ValidationDecision.GO_WITH_CONDITIONS
        elif "go" in response_lower:
            decision = ValidationDecision.GO
        else:
            # Fallback to score-based decision
            avg_score = (feasibility['feasibility_score'] + market['market_score'] + financial['financial_score']) / 3
            if avg_score >= 70:
                decision = ValidationDecision.GO
            elif avg_score >= 50:
                decision = ValidationDecision.GO_WITH_CONDITIONS
            else:
                decision = ValidationDecision.CAUTION
        
        # Calculate overall score
        overall_score = (
            feasibility['feasibility_score'] * 0.25 +
            market['market_score'] * 0.30 +
            financial['financial_score'] * 0.25 +
            max(0, 100 - risk['risk_score']) * 0.20
        )
        
        # Determine confidence based on decision consistency
        confidence = 0.80 if "confident" in response_lower or "strong" in response_lower else 0.65
        
        return decision, round(overall_score, 1), confidence
    
    def _extract_key_insights(self, feasibility: Dict, market: Dict, financial: Dict, risk: Dict) -> List[str]:
        """Extract top insights from all agent analyses"""
        insights = []
        
        # Feasibility insights
        if feasibility['feasibility_score'] > 75:
            insights.append(f"✅ High technical feasibility ({feasibility['feasibility_score']}/100)")
        elif feasibility['feasibility_score'] < 50:
            insights.append(f"⚠️ Technical complexity challenges ({feasibility['feasibility_score']}/100)")
        
        # Market insights
        if market['market_score'] > 70:
            insights.append(f"🎯 Strong market opportunity ({market['market_score']}/100)")
        
        # Financial insights
        business_model = financial['business_model']
        if business_model in ['SaaS/Subscription', 'Marketplace/Platform']:
            insights.append(f"💰 Scalable {business_model} business model")
        
        # Risk insights
        if risk['risk_score'] < 40:
            insights.append("🛡️ Low overall risk profile")
        elif risk['risk_score'] > 70:
            insights.append("⚡ High risk factors require careful management")
        
        return insights[:5]  # Limit to top 5 insights
    
    def _extract_conditions(self, decision: ValidationDecision, feasibility: Dict, market: Dict, financial: Dict, risk: Dict) -> List[str]:
        """Extract conditions for GO_WITH_CONDITIONS decisions"""
        
        if decision != ValidationDecision.GO_WITH_CONDITIONS:
            return []
        
        conditions = []
        
        # Feasibility conditions
        if feasibility['feasibility_score'] < 70:
            conditions.append("🔧 Secure experienced technical team or co-founder")
        
        # Market conditions
        if market['market_score'] < 70:
            conditions.append("📊 Conduct additional market validation before significant investment")
        
        # Financial conditions
        funding_needed = financial['funding_requirements']['total_funding_needed']
        if funding_needed > 500000:
            conditions.append(f"💰 Secure ${funding_needed:,.0f} in funding before launch")
        
        # Risk conditions
        if risk['risk_score'] > 60:
            conditions.append("🛡️ Implement comprehensive risk mitigation strategies")
        
        return conditions
    
    def _extract_top_risks(self, risk: Dict) -> List[str]:
        """Extract top risk factors"""
        all_risks = []
        
        # Collect high severity risks
        for risk_category in ['execution_risks', 'market_risks', 'competitive_risks', 'technical_risks', 'regulatory_risks']:
            risks = risk.get(risk_category, [])
            high_risks = [r['risk'] for r in risks if r.get('severity') == 'High']
            all_risks.extend(high_risks)
        
        return all_risks[:5]  # Top 5 risks
    
    def _generate_recommendations(self, decision: ValidationDecision, feasibility: Dict, market: Dict, financial: Dict, risk: Dict) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        
        if decision == ValidationDecision.GO:
            recommendations.extend([
                "🚀 Proceed with full development and go-to-market planning",
                "⚡ Focus on rapid execution to capitalize on market opportunity",
                "📈 Plan for scaling and growth infrastructure"
            ])
        
        elif decision == ValidationDecision.GO_WITH_CONDITIONS:
            recommendations.extend([
                "🎯 Address identified conditions before major investment",
                "📊 Develop MVP for market validation and learning",
                "🔄 Plan iterative development based on user feedback"
            ])
        
        elif decision == ValidationDecision.CAUTION:
            recommendations.extend([
                "⚠️ Conduct deeper market research and validation",
                "🛠️ Consider significant pivots or model changes",
                "👥 Seek expert advice and mentorship"
            ])
        
        else:  # NO_GO
            recommendations.extend([
                "❌ Do not proceed with current concept",
                "💡 Consider fundamental pivots or alternative opportunities",
                "📚 Learn from analysis for future opportunities"
            ])
        
        # Add specific domain recommendations
        if feasibility['complexity_score'] > 7:
            recommendations.append("🔧 Consider MVP approach to reduce technical risk")
        
        if market['competition_score'] < 50:
            recommendations.append("🎯 Focus on unique differentiation strategy")
        
        return recommendations

# Export main class
__all__ = ['ValidationOrchestrator', 'ValidationResult', 'ValidationDecision']
