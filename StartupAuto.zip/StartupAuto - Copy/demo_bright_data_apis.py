#!/usr/bin/env python3
"""
Demo script showing Bright Data SERP + Crawl API integration for competitor analysis

This demonstrates the API distribution:
- SERP API: Market intelligence gathering
- Crawl API: Deep competitor analysis
"""

import asyncio
import sys
from competitors import CompetitorAgent

async def demo_bright_data_integration():
    """Demonstrate the new Bright Data SERP + Crawl API integration"""
    
    print("🚀 Bright Data SERP + Crawl API Integration Demo")
    print("=" * 60)
    
    # Configuration
    gemini_api_key = "AIzaSyCvPLsiZKzFbvKJEE0ty4a_va1voWVpOcU"
    bright_data_config = {
        "api_key": "3b04bf8daf2ce76e7f7e0dd1e9b96d4700de9e08ad58b946ced4ef756f30b7a2"
    }
    
    business_idea = "AI-powered project management tool for remote teams"
    
    async with CompetitorAgent(
        gemini_api_key=gemini_api_key,
        bright_data_config=bright_data_config
    ) as agent:
        
        print(f"📋 Business Idea: {business_idea}")
        print(f"🔧 APIs Configured: {'✅ SERP + Crawl' if agent.use_real_data else '❌ Fallback mode'}")
        print()
        
        # Phase 1: Traditional competitor analysis
        print("📊 Phase 1: Finding competitors...")
        analysis = await agent.analyze_market(business_idea)
        
        competitor_urls = [comp.website for comp in analysis.competitors[:3] if comp.website]
        print(f"Found {len(competitor_urls)} competitors for deep analysis")
        
        if agent.use_real_data and competitor_urls:
            # Phase 2: Enhanced market intelligence
            print("\n🔬 Phase 2: Comprehensive market intelligence...")
            
            market_intel = await agent.get_comprehensive_market_intelligence(
                business_idea, competitor_urls
            )
            
            if "error" not in market_intel:
                print("\n✅ API Distribution Results:")
                print("━" * 40)
                
                # SERP API Results
                serp_data = market_intel.get("serp_intelligence", {})
                print("📈 SERP API - Market Intelligence:")
                print(f"  • Search visibility analysis: ✅")
                print(f"  • Competitor ranking data: ✅")
                print(f"  • Ad intelligence: ✅")
                print(f"  • Market concentration: {serp_data.get('market_visibility', {}).get('market_concentration', 'unknown')}")
                
                # Crawl API Results  
                insights = market_intel.get("market_insights", {})
                print("\n🔍 Crawl API - Deep Analysis:")
                print(f"  • Website analysis: ✅")
                print(f"  • Feature extraction: {len(insights.get('common_features', []))} features found")
                print(f"  • Pricing analysis: ✅")
                print(f"  • Tech stack detection: ✅")
                print(f"  • Content strategy: ✅")
                
                # Combined Intelligence
                positioning = market_intel.get("competitive_positioning", {})
                print(f"\n💡 Combined Intelligence Score:")
                print(f"  • Market Opportunity: {positioning.get('opportunity_score', 0):.1f}/100")
                print(f"  • Competitive Intensity: {positioning.get('competitive_intensity', 'unknown')}")
                print(f"  • Entry Barriers: {len(positioning.get('entry_barriers', []))}")
                
                print(f"\n📁 Full report saved to: comprehensive_market_intelligence.json")
                
            else:
                print(f"❌ Enhanced analysis failed: {market_intel.get('error')}")
                
        else:
            print("\n⚠️ Enhanced analysis requires Bright Data API credentials")
            print("Demo running in fallback mode")
        
        print(f"\n🎯 Analysis Complete!")
        print(f"Total competitors analyzed: {analysis.total_competitors}")
        print(f"Market maturity: {analysis.market_maturity}")
        print(f"Market gaps identified: {len(analysis.market_gaps)}")

if __name__ == "__main__":
    print("Starting Bright Data SERP + Crawl API demo...")
    asyncio.run(demo_bright_data_integration())
