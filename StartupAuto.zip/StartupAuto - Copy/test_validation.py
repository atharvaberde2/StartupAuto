#!/usr/bin/env python3
"""
Test script for the LlamaIndex-powered validation system
"""

import asyncio
import json
from validation_orchestrator import ValidationOrchestrator, ValidationDecision
from config import Config

async def test_validation_system():
    """Test the complete validation pipeline"""
    
    print("🎯 STARTUP AUTOPILOT - VALIDATION SYSTEM TEST")
    print("=" * 80)
    
    # Initialize validation orchestrator
    config = Config()
    orchestrator = ValidationOrchestrator(config.OPENAI_API_KEY)
    
    # Test business idea
    business_idea = """
    An AI-powered platform that automatically discovers profitable business opportunities 
    by analyzing Reddit discussions, news trends, Google search patterns, and competitive 
    landscapes. It generates comprehensive market validation reports with video demos 
    and audio pitches for instant investor presentations.
    """
    
    print(f"\n📝 Testing Business Idea:")
    print(f"   {business_idea.strip()}")
    
    # Create mock market research data (simulating Stage 1 results)
    mock_market_research = {
        "reddit_analysis": {
            "total_threads": 45,
            "market_validation": {"score": 75},
            "market_size_indicators": {"estimated_market_size": 2500000},
            "user_problems": [
                "Market research takes too long",
                "Hard to validate business ideas", 
                "Need better competitor analysis"
            ]
        },
        "news_analysis": {
            "total_articles": 23,
            "market_momentum": "positive",
            "key_developments": [
                "AI startup funding increases 200%",
                "New market research automation tools launch"
            ]
        },
        "trends_analysis": {
            "total_keywords": 18,
            "market_demand": "high",
            "trending_areas": [
                {"category": "AI automation", "average_score": 78},
                {"category": "market research", "average_score": 65}
            ]
        },
        "competitor_analysis": {
            "total_competitors": 8,
            "market_maturity": "growing",
            "market_gaps": [
                {
                    "description": "No comprehensive AI-powered market validation platform",
                    "opportunity_type": "technology_gap",
                    "potential_size": "large"
                }
            ],
            "barriers_to_entry": "medium"
        },
        "synthesis": {
            "business_name": "MarketAI Pro",
            "market_size": 2500000,
            "validation_score": 78,
            "revenue_potential": "$10M-$100M annually",
            "success_probability": 0.82
        }
    }
    
    # Prepare opportunity data
    opportunity_data = {
        "business_idea": business_idea.strip(),
        "market_research": mock_market_research
    }
    
    try:
        print(f"\n🔄 Running knowledge-driven validation agents...")
        start_time = asyncio.get_event_loop().time()
        
        # Run validation
        validation_result = await orchestrator.validate_opportunity(opportunity_data)
        
        end_time = asyncio.get_event_loop().time()
        duration = end_time - start_time
        
        print(f"\n⏱️  Validation completed in {duration:.1f} seconds")
        
        # Display results
        print_validation_results(validation_result)
        
        # Save results
        save_validation_results(validation_result, business_idea)
        
        print(f"\n✅ Validation system test completed successfully!")
        return True
        
    except Exception as e:
        print(f"\n❌ Validation test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def print_validation_results(result):
    """Print formatted validation results"""
    
    print(f"\n🎯 VALIDATION RESULTS")
    print("=" * 60)
    
    # Overall decision
    decision_emoji = {
        "GO": "🚀",
        "GO_WITH_CONDITIONS": "⚠️",
        "CAUTION": "🟡", 
        "NO_GO": "❌"
    }
    
    emoji = decision_emoji.get(result.decision.value, "❓")
    print(f"\n{emoji} DECISION: {result.decision.value}")
    print(f"📊 Overall Score: {result.overall_score}/100")
    print(f"🎯 Confidence: {result.confidence*100:.1f}%")
    
    # Individual scores
    print(f"\n📈 AGENT SCORES:")
    print(f"   🔧 Feasibility: {result.feasibility_score}/100")
    print(f"   🎯 Market: {result.market_score}/100") 
    print(f"   💰 Financial: {result.financial_score}/100")
    print(f"   🛡️ Risk: {result.risk_score}/100 (lower is better)")
    
    # Key insights
    if result.key_insights:
        print(f"\n💡 KEY INSIGHTS:")
        for i, insight in enumerate(result.key_insights, 1):
            print(f"   {i}. {insight}")
    
    # Conditions
    if result.conditions:
        print(f"\n⚠️ CONDITIONS:")
        for i, condition in enumerate(result.conditions, 1):
            print(f"   {i}. {condition}")
    
    # Risk factors
    if result.risk_factors:
        print(f"\n🚨 RISK FACTORS:")
        for i, risk in enumerate(result.risk_factors[:3], 1):  # Top 3
            print(f"   {i}. {risk}")
    
    # Recommendations
    if result.recommendations:
        print(f"\n🎯 RECOMMENDATIONS:")
        for i, rec in enumerate(result.recommendations[:3], 1):  # Top 3
            print(f"   {i}. {rec}")
    
    # Knowledge sources
    if result.knowledge_sources:
        print(f"\n📚 KNOWLEDGE SOURCES:")
        for source in result.knowledge_sources:
            print(f"   • {source}")

def save_validation_results(result, business_idea):
    """Save validation results to JSON file"""
    
    from datetime import datetime
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"validation_results_{timestamp}.json"
    
    # Convert result to dict for JSON serialization
    save_data = {
        "business_idea": business_idea,
        "validation_timestamp": datetime.now().isoformat(),
        "decision": result.decision.value,
        "overall_score": result.overall_score,
        "confidence": result.confidence,
        "scores": {
            "feasibility": result.feasibility_score,
            "market": result.market_score,
            "financial": result.financial_score,
            "risk": result.risk_score
        },
        "key_insights": result.key_insights,
        "conditions": result.conditions,
        "risk_factors": result.risk_factors,
        "recommendations": result.recommendations,
        "knowledge_sources": result.knowledge_sources,
        "detailed_analysis": result.detailed_analysis
    }
    
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(save_data, f, indent=2, default=str, ensure_ascii=False)
        
        print(f"\n💾 Validation results saved to: {filename}")
        
    except Exception as e:
        print(f"\n❌ Failed to save results: {str(e)}")

async def test_multiple_scenarios():
    """Test validation system with different business scenarios"""
    
    print(f"\n🔬 TESTING MULTIPLE BUSINESS SCENARIOS")
    print("=" * 60)
    
    orchestrator = ValidationOrchestrator(Config().OPENAI_API_KEY)
    
    scenarios = [
        {
            "name": "High-Tech AI Startup",
            "idea": "AI-powered autonomous drone delivery service for medical supplies",
            "expected_decision": "GO_WITH_CONDITIONS"
        },
        {
            "name": "Simple SaaS",
            "idea": "Online appointment scheduling software for small businesses",
            "expected_decision": "GO"
        },
        {
            "name": "Risky Hardware",
            "idea": "Blockchain-powered smart contact lenses with AR display",
            "expected_decision": "CAUTION"
        },
        {
            "name": "Saturated Market",
            "idea": "Another food delivery app for urban areas",
            "expected_decision": "NO_GO"
        }
    ]
    
    results = []
    
    for scenario in scenarios:
        print(f"\n🎯 Testing: {scenario['name']}")
        print(f"   Idea: {scenario['idea']}")
        
        # Create minimal opportunity data
        opportunity_data = {
            "business_idea": scenario["idea"],
            "market_research": {
                "reddit_analysis": {"total_threads": 20, "market_validation": {"score": 60}},
                "competitor_analysis": {"total_competitors": 5, "market_maturity": "growing"},
                "synthesis": {"market_size": 1000000, "validation_score": 65}
            }
        }
        
        try:
            result = await orchestrator.validate_opportunity(opportunity_data)
            results.append({
                "scenario": scenario["name"],
                "decision": result.decision.value,
                "score": result.overall_score,
                "expected": scenario["expected_decision"]
            })
            
            print(f"   ✅ Decision: {result.decision.value} (Score: {result.overall_score}/100)")
            
        except Exception as e:
            print(f"   ❌ Failed: {str(e)}")
            results.append({
                "scenario": scenario["name"],
                "decision": "ERROR",
                "score": 0,
                "expected": scenario["expected_decision"]
            })
    
    # Summary
    print(f"\n📊 SCENARIO TEST SUMMARY:")
    print("-" * 40)
    for result in results:
        expected_match = "✅" if result["decision"] == result["expected"] else "❓"
        print(f"{expected_match} {result['scenario']}: {result['decision']} (Score: {result['score']}/100)")

if __name__ == "__main__":
    import sys
    
    print("Choose test mode:")
    print("1. Single validation test")
    print("2. Multiple scenario tests")
    print("3. Both")
    
    choice = input("\nEnter choice (1, 2, or 3): ").strip()
    
    async def run_tests():
        if choice in ["1", "3"]:
            success = await test_validation_system()
            if not success:
                print("\n⚠️ Single test failed")
        
        if choice in ["2", "3"]:
            await test_multiple_scenarios()
        
        print(f"\n🎉 Testing completed!")
    
    # Run the tests
    asyncio.run(run_tests())
