#!/usr/bin/env python3
"""
Google Veo 3 Integration for Stage 3 Advertisement Generation
Professional video generation using Google's Veo 3 model with business-specific prompts
"""

import os, time
from typing import Optional, TypedDict, Dict
from typing_extensions import Annotated
from langgraph.graph import StateGraph, START, END

# Google Gen AI SDK
from google import genai
from google.genai import types
from google.genai import errors as genai_errors


# -----------------------------
# 1) Enhanced Veo 3 wrapper for business videos
# -----------------------------
class BusinessVeo3Client:
    """
    Enhanced Veo 3 client specifically designed for business advertisement generation.
    Integrates with Stage 1-2 data to create compelling product demo videos.
    
    Setup:
      - Gemini Dev API: export GOOGLE_API_KEY="YOUR_KEY"
      - Vertex AI: export GOOGLE_GENAI_USE_VERTEXAI=true
                  export GOOGLE_CLOUD_PROJECT="your-project-id"  
                  export GOOGLE_CLOUD_LOCATION="us-central1"
    """
    def __init__(self):
        # Auto-configure from environment
        self.client = genai.Client()

    def generate_business_video(
        self,
        business_name: str,
        business_data: Dict,
        video_style: str = "professional_demo",
        out_path: str = "business_demo.mp4",
        *,
        fast: bool = False,
        aspect_ratio: str = "16:9",     # "16:9" for presentations, "9:16" for social
        resolution: str = "1080p",      # "720p" or "1080p"
        duration: int = 75,             # seconds
        custom_prompt: Optional[str] = None
    ) -> Dict:
        """
        Generate a professional business demo video using Veo 3.
        Returns metadata about the generated video.
        """
        
        # Build business-specific prompt
        if custom_prompt:
            prompt = custom_prompt
        else:
            prompt = self._build_business_prompt(
                business_name, business_data, video_style, duration
            )
        
        # Configure Veo 3 parameters
        model = "veo-3.0-fast-generate-001" if fast else "veo-3.0-generate-001"
        
        config = {
            "aspect_ratio": aspect_ratio,
            # Note: resolution parameter not supported in current Gemini API
            # "resolution": resolution,
            # "negative_prompt": "low quality, jitter, heavy motion blur, unprofessional, cartoonish, distorted text",
            # "person_generation": "allow_adult"
        }
        
        try:
            print(f"🎥 Starting Veo 3 generation for {business_name}...")
            print(f"📝 Prompt: {prompt[:100]}...")
            
            op = self.client.models.generate_videos(
                model=model,
                prompt=prompt,
                config=config
            )
            
            # Poll with progress updates
            start_time = time.time()
            while not op.done:
                elapsed = int(time.time() - start_time)
                print(f"⏳ Veo 3 processing... {elapsed}s elapsed")
                time.sleep(15)  # Check every 15 seconds
                op = self.client.operations.get(op)
                
                # Timeout after 10 minutes
                if elapsed > 600:
                    raise RuntimeError("Video generation timed out after 10 minutes")

            # Download the generated video
            vid = op.response.generated_videos[0]
            self.client.files.download(file=vid.video)
            vid.video.save(out_path)
            
            generation_time = int(time.time() - start_time)
            print(f"✅ Video saved: {out_path} (took {generation_time}s)")
            
            return {
                "success": True,
                "video_path": out_path,
                "prompt_used": prompt,
                "generation_time": generation_time,
                "model": model,
                "config": config,
                "file_size": os.path.getsize(out_path) if os.path.exists(out_path) else 0
            }

        except genai_errors.APIError as e:
            raise RuntimeError(f"Veo 3 API error: {e.code} — {e.message}") from e
        except Exception as e:
            raise RuntimeError(f"Video generation failed: {str(e)}") from e

    def _build_business_prompt(
        self, 
        business_name: str, 
        business_data: Dict, 
        style: str, 
        duration: int
    ) -> str:
        """
        Build a compelling, business-specific video prompt for Veo 3.
        Incorporates market validation data and creates professional narratives.
        """
        
        # Extract key metrics from business data
        validation_score = business_data.get('viability_score', 85)
        market_size = business_data.get('reddit_analysis', {}).get('total_market_size', 100000)
        revenue_projection = business_data.get('revenue_analysis', {}).get(
            'growth_forecast', {}
        ).get('month_12', {}).get('annual_run_rate', 1000000)
        
        # Format revenue nicely
        revenue_millions = revenue_projection / 1000000
        
        if style == "professional_demo":
            return f"""
A sophisticated, corporate product demonstration video for {business_name}.

SCENE 1 (0-15s): Sleek studio setup with modern technology aesthetic. Soft key lighting, clean white/blue color palette.
Camera: Slow push-in on elegant product interface mockups floating in 3D space.
SFX: Subtle tech ambience, soft UI interaction sounds.

SCENE 2 (15-35s): Dynamic data visualizations showing market validation.
Visual: Animated charts rising to show {validation_score}% validation score, {market_size:,} potential customers.
Camera: Smooth dolly around floating infographics with depth of field.
SFX: Success chimes, data processing sounds.

SCENE 3 (35-55s): Product features showcase with clean UI animations.
Visual: Interface elements sliding in smoothly, highlighting core functionality.
Camera: Macro close-ups of key features, then wide reveal of complete system.
SFX: Professional click sounds, smooth transitions.

SCENE 4 (55-{duration}s): Revenue projection climax with call-to-action.
Visual: Revenue graph ascending to ${revenue_millions:.1f}M, company logo reveal.
Camera: Dramatic pull-back to show the complete business opportunity.
Dialogue: Professional voiceover: "The future of your industry starts here."
SFX: Triumphant, inspiring background music crescendo.

Style: Premium corporate, technology-focused, investor-presentation quality.
Quality: Professional lighting, smooth camera movements, crisp graphics.
            """.strip()
            
        elif style == "social_media":
            return f"""
High-energy, social media optimized video for {business_name}.

Quick cuts, vibrant colors, mobile-first vertical format.
Text overlays: "🚀 {business_name}", "{validation_score}% Validated", "${revenue_millions:.1f}M Potential"
Camera: Fast-paced montage with dynamic angles.
SFX: Upbeat, modern background music, punchy sound effects.
Style: Energetic, attention-grabbing, designed for viral sharing.
Duration: Optimized for TikTok/Instagram at {duration} seconds.
            """.strip()
            
        elif style == "investor_pitch":
            return f"""
Executive-level investor presentation video for {business_name}.

Professional boardroom aesthetic, data-driven storytelling.
Key metrics prominently displayed: {validation_score}% validation, {market_size:,} market size, ${revenue_millions:.1f}M revenue projection.
Camera: Authoritative, steady shots with confident framing.
Dialogue: "This isn't just an opportunity. This is the validated future of the industry."
Style: Investment-grade presentation, serious, trustworthy, results-focused.
            """.strip()
            
        else:
            # Default professional style
            return f"""
Professional product video for {business_name}.
Clean, modern presentation showcasing market-validated opportunity.
Validation score: {validation_score}%, Market size: {market_size:,}, Revenue potential: ${revenue_millions:.1f}M.
Style: Corporate professional, technology-focused, high-quality production.
            """.strip()


# ----------------------------------------
# 2) LangGraph integration for video workflow
# ----------------------------------------
class VideoGenerationState(TypedDict, total=False):
    business_name: str
    business_data: Dict
    video_style: str
    veo_prompt: str
    veo_params: Dict
    video_path: str
    generation_metadata: Dict


def video_prompt_agent(state: VideoGenerationState) -> VideoGenerationState:
    """Generate business-specific video prompt"""
    business_name = state.get("business_name", "")
    business_data = state.get("business_data", {})
    video_style = state.get("video_style", "professional_demo")
    
    client = BusinessVeo3Client()
    prompt = client._build_business_prompt(business_name, business_data, video_style, 75)
    
    state["veo_prompt"] = prompt
    return state


def video_generation_agent(state: VideoGenerationState) -> VideoGenerationState:
    """Generate video using Veo 3"""
    business_name = state.get("business_name", "")
    business_data = state.get("business_data", {})
    video_style = state.get("video_style", "professional_demo")
    custom_prompt = state.get("veo_prompt")
    params = state.get("veo_params", {})
    
    # Set output path
    safe_name = business_name.lower().replace(' ', '_').replace('-', '_')
    out_path = params.pop("out_path", f"static/generated/video_{safe_name}.mp4")
    
    client = BusinessVeo3Client()
    result = client.generate_business_video(
        business_name=business_name,
        business_data=business_data,
        video_style=video_style,
        out_path=out_path,
        custom_prompt=custom_prompt,
        **params
    )
    
    state["video_path"] = result["video_path"]
    state["generation_metadata"] = result
    return state


def create_video_workflow():
    """Create LangGraph workflow for business video generation"""
    workflow = StateGraph(VideoGenerationState)
    
    workflow.add_node("prompt_agent", video_prompt_agent)
    workflow.add_node("generation_agent", video_generation_agent)
    
    workflow.add_edge(START, "prompt_agent")
    workflow.add_edge("prompt_agent", "generation_agent")
    workflow.add_edge("generation_agent", END)
    
    return workflow.compile()


# ----------------------------------------
# 3) Integration functions for Flask app
# ----------------------------------------
def generate_business_video_for_api(
    business_name: str,
    business_data: Dict,
    video_params: Dict
) -> Dict:
    """
    Main integration function for Flask API.
    Returns result compatible with existing API structure.
    """
    try:
        # Create workflow
        workflow = create_video_workflow()
        
        # Prepare state
        initial_state = {
            "business_name": business_name,
            "business_data": business_data,
            "video_style": video_params.get("video_style", "professional_demo"),
            "veo_params": {
                "aspect_ratio": video_params.get("aspect_ratio", "16:9"),
                "resolution": video_params.get("resolution", "1080p"),
                "fast": video_params.get("fast", False),
                "out_path": f"static/generated/video_{business_name.lower().replace(' ', '_')}.mp4"
            }
        }
        
        # Execute workflow
        result = workflow.invoke(initial_state)
        
        # Format for API response
        metadata = result.get("generation_metadata", {})
        return {
            "success": True,
            "video_url": f"/static/generated/video_{business_name.lower().replace(' ', '_')}.mp4",
            "video_path": result.get("video_path", ""),
            "prompt_used": result.get("veo_prompt", ""),
            "generation_time": metadata.get("generation_time", 0),
            "model": metadata.get("model", "veo-3.0-generate-001"),
            "file_size_mb": round(metadata.get("file_size", 0) / (1024*1024), 2),
            "config": metadata.get("config", {}),
            "id": f"veo3_{int(time.time())}",
            "description": f"Professional video demo for {business_name} generated using Google Veo 3"
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "video_url": "",
            "fallback": True
        }


if __name__ == "__main__":
    # Test the business video generation
    test_business_data = {
        "viability_score": 87,
        "reddit_analysis": {"total_market_size": 250000},
        "revenue_analysis": {
            "growth_forecast": {
                "month_12": {"annual_run_rate": 8500000}
            }
        }
    }
    
    result = generate_business_video_for_api(
        business_name="AI Market Validator Pro",
        business_data=test_business_data,
        video_params={
            "video_style": "professional_demo",
            "resolution": "1080p",
            "aspect_ratio": "16:9"
        }
    )
    
    print("Video generation result:", result)
