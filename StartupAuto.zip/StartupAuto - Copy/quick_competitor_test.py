#!/usr/bin/env python3
"""
Quick test to verify competitor agent works properly
"""

import asyncio
from competitors import CompetitorAgent

async def quick_test():
    """Quick test of competitor agent functionality"""
    
    print("🚀 Quick Competitor Agent Test")
    print("=" * 40)
    
    # Configuration with real API key
    gemini_api_key = "AIzaSyCvPLsiZKzFbvKJEE0ty4a_va1voWVpOcU"
    bright_data_config = {
        "api_key": "3b04bf8daf2ce76e7f7e0dd1e9b96d4700de9e08ad58b946ced4ef756f30b7a2"
    }
    
    # Test business idea
    business_idea = "AI-powered email marketing automation tool"
    
    try:
        async with CompetitorAgent(
            gemini_api_key=gemini_api_key,
            bright_data_config=bright_data_config
        ) as agent:
            
            print(f"📧 Testing: {business_idea}")
            print(f"🔧 Real data mode: {agent.use_real_data}")
            print(f"📊 SERP API: Ready")
            print(f"🔍 Crawl API: Ready")
            print()
            
            # Quick analysis
            print("Running competitor analysis...")
            analysis = await agent.analyze_market(business_idea)
            
            print(f"\n✅ Analysis Results:")
            print(f"   • Market: {analysis.market_category}")
            print(f"   • Competitors: {analysis.total_competitors}")
            print(f"   • Maturity: {analysis.market_maturity}")
            print(f"   • Gaps: {len(analysis.market_gaps)}")
            
            if analysis.competitors:
                print(f"\n🏢 Top 3 Competitors:")
                for i, comp in enumerate(analysis.competitors[:3], 1):
                    print(f"   {i}. {comp.name}")
                    print(f"      • Website: {comp.website}")
                    print(f"      • Position: {comp.market_position}")
                    print(f"      • Score: {comp.competitive_score:.1f}/100")
            
            if analysis.market_gaps:
                print(f"\n🎯 Market Opportunities:")
                for i, gap in enumerate(analysis.market_gaps[:2], 1):
                    print(f"   {i}. {gap.description}")
            
            print(f"\n🎉 Test Complete - Agent Working Properly!")
            return True
            
    except Exception as e:
        print(f"❌ Test Failed: {str(e)}")
        return False

if __name__ == "__main__":
    success = asyncio.run(quick_test())
    exit(0 if success else 1)
