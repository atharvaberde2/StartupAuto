# 🎥 Google Veo 3 Setup Guide for Stage 3

## Overview

This guide shows you how to set up real Google Veo 3 video generation for your Stage 3 Advertisement Generator. The system includes fallback mode, so it works with or without Veo 3 configured.

## Setup Options

### Option 1: Gemini Developer API (Simplest)

1. **Get API Key**:
   - Go to [Google AI Studio](https://aistudio.google.com/)
   - Create a new API key
   - Copy your API key

2. **Set Environment Variable**:
   ```bash
   # Windows (PowerShell)
   $env:GOOGLE_API_KEY="your_gemini_api_key_here"
   
   # Windows (Command Prompt)
   set GOOGLE_API_KEY=your_gemini_api_key_here
   
   # Linux/Mac
   export GOOGLE_API_KEY="your_gemini_api_key_here"
   ```

3. **Install Dependencies**:
   ```bash
   pip install google-genai>=0.9.0
   ```

### Option 2: Vertex AI (Enterprise)

1. **Set up Google Cloud Project**:
   ```bash
   # Install Google Cloud CLI
   # Set up authentication
   gcloud auth application-default login
   ```

2. **Set Environment Variables**:
   ```bash
   export GOOGLE_GENAI_USE_VERTEXAI=true
   export GOOGLE_CLOUD_PROJECT="your-project-id"
   export GOOGLE_CLOUD_LOCATION="us-central1"
   ```

## Testing the Integration

### 1. Test Veo 3 Availability
```python
from veo3_integration import BusinessVeo3Client

try:
    client = BusinessVeo3Client()
    print("✅ Google Veo 3 client initialized successfully")
except Exception as e:
    print(f"❌ Veo 3 setup issue: {e}")
```

### 2. Test Video Generation
```python
python veo3_integration.py
```

### 3. Test Full API Integration
```python
python test_ad_generation.py
```

## Configuration in Your System

The Stage 3 system automatically detects Veo 3 availability:

- **✅ Veo 3 Available**: Uses real Google Veo 3 for video generation
- **⚠️ Veo 3 Unavailable**: Falls back to placeholder mode (still functional)

## Video Generation Parameters

### Standard Parameters
```javascript
{
  "business_name": "Your Business",
  "business_data": { /* Stage 1-2 analysis */ },
  "video_style": "professional_demo",    // or "social_media", "investor_pitch"
  "resolution": "1080p",                 // or "720p"
  "aspect_ratio": "16:9",               // or "9:16" for social media
  "duration": 75,                       // seconds
  "fast": false                         // true for faster generation
}
```

### Video Styles Available

#### 1. Professional Demo (`professional_demo`)
- **Use Case**: Investor presentations, corporate websites
- **Duration**: 60-90 seconds
- **Style**: Premium corporate, technology-focused
- **Includes**: Market validation data, revenue projections, product features

#### 2. Social Media (`social_media`)
- **Use Case**: TikTok, Instagram, viral marketing
- **Duration**: 15-60 seconds
- **Style**: High-energy, fast-paced, mobile-optimized
- **Format**: Vertical (9:16) recommended

#### 3. Investor Pitch (`investor_pitch`)
- **Use Case**: Board presentations, funding meetings
- **Duration**: 75-120 seconds
- **Style**: Executive-level, data-driven, authoritative
- **Includes**: ROI metrics, market size, competitive analysis

## Business-Specific Prompts

The system automatically generates compelling video prompts based on your Stage 1-2 data:

```python
# Example generated prompt for "AI Market Validator"
"""
A sophisticated, corporate product demonstration video for AI Market Validator.

SCENE 1 (0-15s): Sleek studio setup with modern technology aesthetic.
Camera: Slow push-in on elegant product interface mockups.
SFX: Subtle tech ambience, soft UI interaction sounds.

SCENE 2 (15-35s): Dynamic data visualizations showing 87% validation score.
Visual: Animated charts rising to show 250,000 potential customers.
Camera: Smooth dolly around floating infographics.

SCENE 3 (35-55s): Product features showcase with clean UI animations.
Camera: Macro close-ups of key features, then wide reveal.

SCENE 4 (55-75s): Revenue projection climax - $8.5M annually.
Dialogue: "The future of your industry starts here."
Style: Premium corporate, investor-presentation quality.
"""
```

## API Response Structure

### Successful Generation
```json
{
  "success": true,
  "video_url": "/static/generated/video_ai_market_validator.mp4",
  "video_path": "full/path/to/video.mp4",
  "prompt_used": "Full Veo 3 prompt...",
  "generation_time": 180,
  "model": "veo-3.0-generate-001",
  "file_size_mb": 45.2,
  "config": {
    "aspect_ratio": "16:9",
    "resolution": "1080p"
  }
}
```

### Fallback Mode
```json
{
  "success": true,
  "video_url": "/static/generated/video_placeholder.mp4",
  "fallback_mode": true,
  "description": "Professional concept ready for Veo 3 generation"
}
```

## Production Considerations

### Performance Optimization
- **Fast Mode**: Use `"fast": true` for quicker generation (slightly lower quality)
- **Resolution**: Use 720p for faster processing, 1080p for premium quality
- **Caching**: Generated videos are cached in `static/generated/`

### Cost Management
- Veo 3 generation typically takes 2-5 minutes per video
- Consider using fast mode for development/testing
- Cache videos to avoid regenerating identical content

### Error Handling
The system includes comprehensive error handling:
- API timeout protection (10-minute max)
- Graceful fallback to placeholder mode
- Detailed error logging for debugging

## Troubleshooting

### Common Issues

#### 1. "Veo 3 not available" Message
- Check API key is set correctly
- Verify `google-genai` package is installed
- Test with: `python -c "from google import genai; print('OK')"`

#### 2. Generation Timeout
- Videos can take 2-10 minutes to generate
- Check internet connection
- Try fast mode: `"fast": true`

#### 3. API Quota Exceeded
- Check your Google AI Studio quota
- Consider using Vertex AI for higher limits
- Implement request queuing for high-volume usage

### Debug Mode
Enable detailed logging:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## Integration Checklist

- [ ] ✅ API key configured (`GOOGLE_API_KEY` or Vertex AI)
- [ ] ✅ Dependencies installed (`google-genai>=0.9.0`)
- [ ] ✅ Test script runs successfully
- [ ] ✅ Flask app starts without errors
- [ ] ✅ Video generation works in browser
- [ ] ✅ Fallback mode works if Veo 3 unavailable

## Support

The system is designed to be robust:
- **Works without Veo 3**: Full functionality in fallback mode
- **Production Ready**: Comprehensive error handling
- **Scalable**: LangGraph workflow for complex video generation

For issues or enhancements, the Veo 3 integration is modular and can be extended independently of the core Stage 3 system.

---

**Your Stage 3 system now includes cutting-edge Google Veo 3 video generation! 🎬**
