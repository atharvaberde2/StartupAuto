"""
Test Bright Data Web Unlocker API with correct endpoint and format
"""
import asyncio
import aiohttp
import json
from config import Config

async def test_bright_data_unlocker():
    """Test Bright Data Web Unlocker API"""
    config = Config()
    
    print("🔍 Testing Bright Data Web Unlocker API...")
    print(f"API Key: {config.BRIGHT_DATA_API_KEY[:20]}***")
    print(f"Zone: {config.BRIGHT_DATA_ZONE}")
    print(f"Endpoint: {config.BRIGHT_DATA_ENDPOINT}")
    
    headers = {
        "Authorization": f"Bearer {config.BRIGHT_DATA_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Test with the exact format from the curl command
    test_payloads = [
        # Official test endpoint
        {
            "zone": config.BRIGHT_DATA_ZONE,
            "url": "https://geo.brdtest.com/welcome.txt?product=unlocker&method=api",
            "format": "raw"
        },
        # Test with JSON format
        {
            "zone": config.BRIGHT_DATA_ZONE,
            "url": "https://httpbin.org/get",
            "format": "json"
        }
    ]
    
    try:
        async with aiohttp.ClientSession() as session:
            print(f"\n📡 Testing API endpoint: {config.BRIGHT_DATA_ENDPOINT}")
            
            for i, payload in enumerate(test_payloads, 1):
                print(f"\n🧪 Test {i}/2:")
                print(f"Payload: {payload}")
                
                try:
                    async with session.post(
                        config.BRIGHT_DATA_ENDPOINT, 
                        headers=headers, 
                        json=payload, 
                        timeout=30
                    ) as response:
                        print(f"Status Code: {response.status}")
                        
                        if response.status == 200:
                            if payload["format"] == "raw":
                                data = await response.text()
                                print(f"✅ SUCCESS! Raw response: {data[:200]}...")
                            else:
                                data = await response.json()
                                print(f"✅ SUCCESS! JSON response: {json.dumps(data, indent=2)[:300]}...")
                            return True
                        else:
                            response_text = await response.text()
                            print(f"❌ Failed: {response_text}")
                            
                except Exception as e:
                    print(f"❌ Request failed: {str(e)}")
                    
                print("-" * 50)
            
            return False
                    
    except Exception as e:
        print(f"❌ Connection error: {str(e)}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("🚀 BRIGHT DATA WEB UNLOCKER TEST")
    print("=" * 60)
    
    success = asyncio.run(test_bright_data_unlocker())
    
    print("\n" + "=" * 60)
    if success:
        print("✅ Bright Data Web Unlocker API working!")
    else:
        print("❌ Bright Data Web Unlocker API issues")
    print("=" * 60)
