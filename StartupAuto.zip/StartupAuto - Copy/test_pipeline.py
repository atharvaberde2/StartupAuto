"""
Test script for the Startup Autopilot Market Research Pipeline
Tests the complete LangGraph orchestrator with all 4 agents
"""

import asyncio
import json
import logging
from datetime import datetime

from market_research_orchestrator import MarketResearchOrchestrator

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def test_market_research_pipeline():
    """Test the complete market research pipeline"""
    
    print("🚀 STARTUP AUTOPILOT - MARKET RESEARCH PIPELINE TEST")
    print("=" * 80)
    
    # Initialize orchestrator
    orchestrator = MarketResearchOrchestrator()
    
    # Test business idea
    business_idea = """
    An AI-powered platform that automatically discovers profitable business opportunities 
    by analyzing Reddit discussions, news trends, Google search patterns, and competitive 
    landscapes. It generates comprehensive market validation reports with video demos 
    and audio pitches for instant investor presentations.
    """
    
    print(f"\n📝 Testing Business Idea:")
    print(f"   {business_idea.strip()}")
    
    try:
        print(f"\n🔄 Starting comprehensive market research...")
        start_time = datetime.now()
        
        # Run the market research pipeline
        results = await orchestrator.run_market_research(business_idea.strip())
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        print(f"\n⏱️  Analysis completed in {duration:.1f} seconds")
        
        # Check if analysis was successful
        if results.get('status') == 'failed':
            print(f"❌ Analysis failed: {results.get('error')}")
            return False
        
        # Display results
        print_results_summary(results)
        
        # Save detailed results
        save_results_to_file(results, business_idea)
        
        print(f"\n✅ Market research pipeline test completed successfully!")
        return True
        
    except Exception as e:
        print(f"\n❌ Pipeline test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def print_results_summary(results):
    """Print a summary of the research results"""
    
    print(f"\n📊 RESEARCH RESULTS SUMMARY")
    print("=" * 60)
    
    # Overall status
    status = results.get('status', 'unknown')
    progress = results.get('progress', 0)
    print(f"Status: {status.upper()} | Progress: {progress}%")
    
    # Reddit Analysis
    reddit_data = results.get('reddit_analysis', {})
    if reddit_data and 'error' not in reddit_data:
        print(f"\n🔍 REDDIT ANALYSIS:")
        print(f"   • Threads analyzed: {reddit_data.get('total_threads', 0)}")
        print(f"   • Validation score: {reddit_data.get('market_validation', {}).get('score', 0)}/100")
        print(f"   • Market size estimate: {reddit_data.get('market_size_indicators', {}).get('estimated_market_size', 0):,}")
        
        user_problems = reddit_data.get('user_problems', [])
        if user_problems:
            print(f"   • Top user problems found:")
            for i, problem in enumerate(user_problems[:3], 1):
                print(f"     {i}. {problem[:80]}...")
    else:
        print(f"\n🔍 REDDIT ANALYSIS: ❌ Failed - {reddit_data.get('error', 'Unknown error')}")
    
    # News Analysis
    news_data = results.get('news_analysis', {})
    if news_data and 'error' not in news_data:
        print(f"\n📰 NEWS ANALYSIS:")
        print(f"   • Articles analyzed: {news_data.get('total_articles', 0)}")
        print(f"   • Market momentum: {news_data.get('market_momentum', 'unknown').upper()}")
        
        key_developments = news_data.get('key_developments', [])
        if key_developments:
            print(f"   • Key developments:")
            for i, dev in enumerate(key_developments[:3], 1):
                print(f"     {i}. {dev[:80]}...")
    else:
        print(f"\n📰 NEWS ANALYSIS: ❌ Failed - {news_data.get('error', 'Unknown error')}")
    
    # Google Trends Analysis
    trends_data = results.get('trends_analysis', {})
    if trends_data and 'error' not in trends_data:
        print(f"\n📈 GOOGLE TRENDS ANALYSIS:")
        print(f"   • Keywords analyzed: {trends_data.get('total_keywords', 0)}")
        print(f"   • Market demand: {trends_data.get('market_demand', 'unknown').upper()}")
        
        trending_areas = trends_data.get('trending_areas', [])
        if trending_areas:
            print(f"   • Top trending areas:")
            for i, area in enumerate(trending_areas[:3], 1):
                print(f"     {i}. {area.get('category', 'Unknown')}: {area.get('average_score', 0)} avg score")
    else:
        print(f"\n📈 GOOGLE TRENDS ANALYSIS: ❌ Failed - {trends_data.get('error', 'Unknown error')}")
    
    # Competitor Analysis
    competitor_data = results.get('competitor_analysis', {})
    if competitor_data and 'error' not in competitor_data:
        print(f"\n🏢 COMPETITOR ANALYSIS:")
        print(f"   • Competitors analyzed: {competitor_data.get('total_competitors', 0)}")
        print(f"   • Market maturity: {competitor_data.get('market_maturity', 'unknown').upper()}")
        print(f"   • Market gaps found: {len(competitor_data.get('market_gaps', []))}")
        print(f"   • Barriers to entry: {competitor_data.get('barriers_to_entry', 'unknown').upper()}")
    else:
        print(f"\n🏢 COMPETITOR ANALYSIS: ❌ Failed - {competitor_data.get('error', 'Unknown error')}")
    
    # Synthesis Results
    synthesis = results.get('synthesis', {})
    if synthesis and 'error' not in synthesis:
        print(f"\n🧠 AI SYNTHESIS:")
        print(f"   • Business name: {synthesis.get('business_name', 'Unknown')}")
        print(f"   • Market size: {synthesis.get('market_size', 0):,}")
        print(f"   • Validation score: {synthesis.get('validation_score', 0)}/100")
        print(f"   • Revenue potential: {synthesis.get('revenue_potential', 'Unknown')}")
        print(f"   • Success probability: {synthesis.get('success_probability', 0)*100:.1f}%")
        
        key_insights = synthesis.get('key_insights', [])
        if key_insights:
            print(f"   • Key insights:")
            for i, insight in enumerate(key_insights[:3], 1):
                print(f"     {i}. {insight}")
    else:
        print(f"\n🧠 AI SYNTHESIS: ❌ Failed - {synthesis.get('error', 'Unknown error')}")
    
    # Errors
    errors = results.get('errors', [])
    if errors:
        print(f"\n⚠️  ERRORS ENCOUNTERED:")
        for i, error in enumerate(errors, 1):
            print(f"   {i}. {error}")

def save_results_to_file(results, business_idea):
    """Save detailed results to a JSON file"""
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"market_research_results_{timestamp}.json"
    
    # Prepare data for saving
    save_data = {
        "business_idea": business_idea,
        "analysis_timestamp": datetime.now().isoformat(),
        "results": results
    }
    
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(save_data, f, indent=2, default=str, ensure_ascii=False)
        
        print(f"\n💾 Detailed results saved to: {filename}")
        
    except Exception as e:
        print(f"\n❌ Failed to save results: {str(e)}")

async def test_individual_agents():
    """Test individual agents separately for debugging"""
    
    print(f"\n🔧 INDIVIDUAL AGENT TESTS")
    print("=" * 50)
    
    business_idea = "AI-powered market research platform"
    
    orchestrator = MarketResearchOrchestrator()
    
    # Test Reddit Agent
    print(f"\n1. Testing Reddit Agent...")
    try:
        reddit_agent = orchestrator.reddit_agent
        if reddit_agent is None:
            # Initialize manually for testing
            from reddit import ProjectProblemFinder
            from config import Config
            config = Config()
            reddit_agent = ProjectProblemFinder(
                openai_api_key=config.OPENAI_API_KEY,
                reddit_client_id=config.REDDIT_CLIENT_ID,
                reddit_client_secret=config.REDDIT_CLIENT_SECRET,
                reddit_user_agent=config.REDDIT_USER_AGENT
            )
        
        reddit_results = reddit_agent.analyze_and_search(business_idea, limit_total=10)
        print(f"   ✅ Reddit: Found {len(reddit_results.get('threads', []))} threads")
        
    except Exception as e:
        print(f"   ❌ Reddit: {str(e)}")
    
    # Test Google Trends Agent
    print(f"\n2. Testing Google Trends Agent...")
    try:
        from google_pytrend import GooglePyTrendsAgent
        from config import Config
        config = Config()
        
        trends_agent = GooglePyTrendsAgent(openai_api_key=config.GOOGLE_TRENDS_OPENAI_KEY)
        trends_results = await trends_agent.analyze_project_trends(business_idea)
        print(f"   ✅ Trends: Analyzed {trends_results['summary']['total_keywords_analyzed']} keywords")
        
    except Exception as e:
        print(f"   ❌ Trends: {str(e)}")
    
    # Test News Agent
    print(f"\n3. Testing News Agent...")
    try:
        from news import fetch_news_articles
        from config import Config
        from datetime import datetime, timedelta
        
        config = Config()
        keywords = ["AI", "market research", "automation"]
        today = datetime.today().strftime("%Y-%m-%d")
        from_date = (datetime.today() - timedelta(days=30)).strftime("%Y-%m-%d")
        
        articles = fetch_news_articles(config.NEWS_API_KEY, keywords, from_date, today, page_size=10)
        print(f"   ✅ News: Found {len(articles)} articles")
        
    except Exception as e:
        print(f"   ❌ News: {str(e)}")
    
    # Test Competitor Agent
    print(f"\n4. Testing Competitor Agent...")
    try:
        from competitors import CompetitorAgent
        from config import Config
        
        config = Config()
        async with CompetitorAgent(config.GEMINI_API_KEY) as competitor_agent:
            analysis = await competitor_agent.analyze_market(business_idea)
            print(f"   ✅ Competitors: Analyzed {analysis.total_competitors} competitors")
        
    except Exception as e:
        print(f"   ❌ Competitors: {str(e)}")

if __name__ == "__main__":
    print("Choose test mode:")
    print("1. Full pipeline test")
    print("2. Individual agent tests")
    print("3. Both")
    
    choice = input("\nEnter choice (1, 2, or 3): ").strip()
    
    async def run_tests():
        if choice in ["1", "3"]:
            success = await test_market_research_pipeline()
            if not success:
                print("\n⚠️  Pipeline test failed, running individual tests for debugging...")
                await test_individual_agents()
        
        if choice in ["2", "3"]:
            await test_individual_agents()
        
        print(f"\n🎯 Testing completed!")
    
    # Run the tests
    asyncio.run(run_tests())
