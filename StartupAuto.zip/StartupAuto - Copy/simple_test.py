"""
Simple test to verify the system works without the full Flask app
"""

def test_imports():
    """Test that all modules can be imported"""
    print("🧪 Testing imports...")
    
    try:
        from langgraph.graph import StateGraph, END
        print("✅ LangGraph imported successfully")
    except Exception as e:
        print(f"❌ LangGraph import failed: {e}")
        return False
    
    try:
        from langchain_openai import ChatOpenAI
        print("✅ LangChain OpenAI imported successfully")
    except Exception as e:
        print(f"❌ LangChain OpenAI import failed: {e}")
        return False
    
    try:
        from market_research_orchestrator import MarketResearchOrchestrator
        print("✅ Market Research Orchestrator imported successfully")
    except Exception as e:
        print(f"❌ Orchestrator import failed: {e}")
        return False
    
    try:
        from config import Config
        print("✅ Config imported successfully")
    except Exception as e:
        print(f"❌ Config import failed: {e}")
        return False
    
    return True

def test_orchestrator_creation():
    """Test creating the orchestrator"""
    print("\n🧪 Testing orchestrator creation...")
    
    try:
        from market_research_orchestrator import MarketResearchOrchestrator
        orchestrator = MarketResearchOrchestrator()
        print("✅ Orchestrator created successfully")
        return True
    except Exception as e:
        print(f"❌ Orchestrator creation failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_individual_agents():
    """Test individual agents"""
    print("\n🧪 Testing individual agents...")
    
    # Test Reddit agent
    try:
        from reddit import ProjectProblemFinder
        print("✅ Reddit agent imported successfully")
    except Exception as e:
        print(f"❌ Reddit agent import failed: {e}")
    
    # Test News agent
    try:
        from news import fetch_news_articles
        print("✅ News agent imported successfully")
    except Exception as e:
        print(f"❌ News agent import failed: {e}")
    
    # Test Google Trends agent
    try:
        from google_pytrend import GooglePyTrendsAgent
        print("✅ Google Trends agent imported successfully")
    except Exception as e:
        print(f"❌ Google Trends agent import failed: {e}")
    
    # Test Competitors agent
    try:
        from competitors import CompetitorAgent
        print("✅ Competitors agent imported successfully")
    except Exception as e:
        print(f"❌ Competitors agent import failed: {e}")

def main():
    """Run all tests"""
    print("🚀 STARTUP AUTOPILOT - SYSTEM TESTS")
    print("=" * 50)
    
    # Test 1: Imports
    if not test_imports():
        print("\n❌ Import tests failed!")
        return False
    
    # Test 2: Orchestrator creation
    if not test_orchestrator_creation():
        print("\n❌ Orchestrator tests failed!")
        return False
    
    # Test 3: Individual agents
    test_individual_agents()
    
    print("\n" + "=" * 50)
    print("✅ ALL TESTS PASSED!")
    print("🎉 Your Startup Autopilot system is ready to go!")
    print("\nNext steps:")
    print("1. Configure your API keys in config.py")
    print("2. Run: python app.py (for web interface)")
    print("3. Or run: python test_pipeline.py (for full test)")
    
    return True

if __name__ == "__main__":
    main()
