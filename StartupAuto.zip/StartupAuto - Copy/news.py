import requests
from urllib.parse import quote
from datetime import datetime, timedelta

API_KEY = "fa207cf9d2d74e7db0c5238055a3c445"
KEYWORDS = ["fitness", "workout", "wellness", "gym"]
DAYS_TO_TRACK = 30
ARTICLES_PER_KEYWORD = 20

def fetch_news_articles(api_key, keywords, from_date, to_date, page_size=20):
    articles = []
    for keyword in keywords:
        try:
            q = quote(keyword)
            url = (
                f"https://newsapi.org/v2/everything?"
                f"q={q}&from={from_date}&to={to_date}&language=en"
                f"&sortBy=relevancy&pageSize={page_size}&apiKey={api_key}"
            )
            response = requests.get(url)
            data = response.json()
            if data.get('status') == 'ok':
                for article in data['articles']:
                    article['keyword'] = keyword
                    articles.append(article)
            else:
                print(f"Error for '{keyword}': {data.get('message')}")
        except Exception as e:
            print(f"Error fetching news for '{keyword}': {str(e)}")
    return articles

def get_news_analysis(business_idea=None):
    """Get news articles for analysis - only runs when called"""
    today = datetime.today().strftime("%Y-%m-%d")
    from_date = (datetime.today() - timedelta(days=DAYS_TO_TRACK)).strftime("%Y-%m-%d")
    
    # Use business-specific keywords if provided, otherwise use defaults
    keywords = KEYWORDS
    if business_idea:
        # Extract relevant keywords from business idea (simplified)
        keywords = KEYWORDS  # For now, keep using default keywords
    
    articles = fetch_news_articles(API_KEY, keywords, from_date, today, ARTICLES_PER_KEYWORD)
    
    return {
        'total_articles': len(articles),
        'articles': articles[:10],  # Return first 10 for analysis
        'keywords_analyzed': keywords,
        'date_range': f"{from_date} to {today}"
    }

# Only run when executed directly (not imported)
if __name__ == "__main__":
    today = datetime.today().strftime("%Y-%m-%d")
    from_date = (datetime.today() - timedelta(days=DAYS_TO_TRACK)).strftime("%Y-%m-%d")
    
    articles = fetch_news_articles(API_KEY, KEYWORDS, from_date, today, ARTICLES_PER_KEYWORD)
    
    # Print all article links (only when run directly)
    for article in articles:
        print(f"[{article['keyword']}] {article['url']}")