import os
import time
import logging
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import json
import asyncio
from concurrent.futures import ThreadPoolExecutor

# External libraries
import openai
from pytrends.request import TrendReq
import pandas as pd
import numpy as np
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class TrendData:
    """Data structure for trend information"""
    keyword: str
    category: str
    interest_over_time: Dict[str, Any]
    related_queries: Dict[str, Any]
    regional_interest: Dict[str, Any]
    rising_queries: List[str]
    top_queries: List[str]
    trend_score: float
    market_potential: str


class GooglePyTrendsAgent:
    """
    Autonomous Google Trends Analysis Agent for Market Research
    Integrates with OpenAI GPT-4 for intelligent keyword generation
    """

    def __init__(self, openai_api_key: str, geo: str = 'US', timeout: int = 30):
        """
        Initialize the PyTrends Agent

        Args:
            openai_api_key: OpenAI API key for GPT-4 keyword generation
            geo: Geographic location for trends (default: 'US')
            timeout: Request timeout in seconds
        """
        self.openai_client = openai.OpenAI(api_key=openai_api_key)

        # Initialize PyTrends with compatible parameters
        try:
            # Try the newer parameter format first
            self.pytrends = TrendReq(hl='en-US', tz=360, timeout=(5, 25))
        except Exception as e:
            logger.warning(f"Failed to initialize with timeout tuple, trying legacy format: {e}")
            try:
                # Fallback to basic initialization
                self.pytrends = TrendReq(hl='en-US', tz=360)
            except Exception as e2:
                logger.error(f"Failed to initialize PyTrends: {e2}")
                raise

        self.geo = geo
        self.executor = ThreadPoolExecutor(max_workers=5)

        # GPT-4 prompt template
        self.keyword_generation_prompt = """
        You are a Google Trends keyword strategist. For the project "{project}", generate search terms that will reveal market demand patterns and emerging opportunities.

        Provide 10-15 keywords/phrases across these categories:
        - Core problem keywords (3-4): What pain points does this solve?
        - Solution-seeking terms (3-4): How do people search for solutions?
        - Industry/vertical terms (2-3): What industry/market context?
        - Competitor/alternative terms (3-4): What existing solutions exist?
        - Trend indicators (2-3): Include "best", "new", "2024", "2025", etc.

        Use terms people actually search for, including common misspellings and variations.
        Output as a JSON object with categories as keys and arrays of keywords as values.

        Example format:
        {{
            "core_problems": ["keyword1", "keyword2"],
            "solution_seeking": ["keyword1", "keyword2"],
            "industry_terms": ["keyword1", "keyword2"],
            "competitors": ["keyword1", "keyword2"],
            "trend_indicators": ["keyword1", "keyword2"]
        }}
        """

    async def generate_keywords(self, project_description: str) -> Dict[str, List[str]]:
        """
        Generate keywords using GPT-4 for the given project

        Args:
            project_description: Description of the project/business idea

        Returns:
            Dictionary of categorized keywords
        """
        try:
            logger.info(f"Generating keywords for project: {project_description[:100]}...")

            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an expert Google Trends keyword strategist."},
                    {"role": "user", "content": self.keyword_generation_prompt.format(project=project_description)}
                ],
                temperature=0.7,
                max_tokens=1000
            )

            # Parse JSON response
            content = response.choices[0].message.content.strip()

            # Clean up response to extract JSON
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0].strip()
            elif "```" in content:
                content = content.split("```")[1].split("```")[0].strip()

            keywords_dict = json.loads(content)

            # Flatten all keywords for processing
            all_keywords = []
            for category, keywords in keywords_dict.items():
                for keyword in keywords:
                    all_keywords.append((keyword, category))

            logger.info(f"Generated {len(all_keywords)} keywords across {len(keywords_dict)} categories")
            return keywords_dict, all_keywords

        except Exception as e:
            logger.error(f"Error generating keywords: {str(e)}")
            # Fallback keywords if GPT-4 fails
            return self._get_fallback_keywords(project_description)

    def _get_fallback_keywords(self, project: str) -> tuple:
        """Fallback keywords if GPT-4 fails"""
        fallback = {
            "core_problems": [project, f"{project} problem", f"{project} issue"],
            "solution_seeking": [f"{project} solution", f"how to {project}", f"{project} tool"],
            "industry_terms": [f"{project} market", f"{project} industry"],
            "competitors": [f"{project} alternative", f"best {project}"],
            "trend_indicators": [f"{project} 2024", f"new {project}"]
        }
        all_keywords = [(kw, cat) for cat, keywords in fallback.items() for kw in keywords]
        return fallback, all_keywords

    def analyze_keyword_batch(self, keywords: List[str], category: str = "general") -> List[TrendData]:
        """
        Analyze a batch of keywords (max 5 at once for PyTrends)

        Args:
            keywords: List of keywords to analyze (max 5)
            category: Category these keywords belong to

        Returns:
            List of TrendData objects
        """
        try:
            # Limit to 5 keywords per request (PyTrends limitation)
            keywords = keywords[:5]

            logger.info(f"Analyzing keywords: {keywords}")

            results = []

            # Process each keyword individually to avoid payload issues
            for keyword in keywords:
                try:
                    # Build payload for single keyword
                    self.pytrends.build_payload([keyword], cat=0, timeframe='today 12-m', geo=self.geo, gprop='')

                    # Get interest over time
                    interest_over_time = self.pytrends.interest_over_time()

                    # Get related queries with error handling
                    rising_queries = []
                    top_queries = []
                    related_queries = {}

                    try:
                        related_queries = self.pytrends.related_queries()
                        if keyword in related_queries:
                            if related_queries[keyword]['rising'] is not None:
                                rising_queries = related_queries[keyword]['rising']['query'].tolist()[:5]
                            if related_queries[keyword]['top'] is not None:
                                top_queries = related_queries[keyword]['top']['query'].tolist()[:5]
                    except Exception as e:
                        logger.warning(f"Could not fetch related queries for '{keyword}': {str(e)}")

                    # Get regional interest with error handling
                    regional_interest = pd.DataFrame()
                    try:
                        regional_interest = self.pytrends.interest_by_region()
                    except Exception as e:
                        logger.warning(f"Could not fetch regional interest for '{keyword}': {str(e)}")

                    # Calculate trend score
                    trend_score = self._calculate_trend_score(interest_over_time, keyword, rising_queries)

                    # Determine market potential
                    market_potential = self._assess_market_potential(trend_score, len(rising_queries))

                    trend_data = TrendData(
                        keyword=keyword,
                        category=category,
                        interest_over_time=interest_over_time.to_dict() if not interest_over_time.empty else {},
                        related_queries=related_queries,
                        regional_interest=regional_interest.to_dict() if not regional_interest.empty else {},
                        rising_queries=rising_queries,
                        top_queries=top_queries,
                        trend_score=trend_score,
                        market_potential=market_potential
                    )

                    results.append(trend_data)

                    # Rate limiting between individual keyword requests
                    time.sleep(3)

                except Exception as e:
                    logger.warning(f"Error analyzing keyword '{keyword}': {str(e)}")
                    # Create a minimal TrendData object for failed keywords
                    trend_data = TrendData(
                        keyword=keyword,
                        category=category,
                        interest_over_time={},
                        related_queries={},
                        regional_interest={},
                        rising_queries=[],
                        top_queries=[],
                        trend_score=0.0,
                        market_potential="MINIMAL"
                    )
                    results.append(trend_data)
                    continue

            return results

        except Exception as e:
            logger.error(f"Error in batch analysis: {str(e)}")
            return []

    def _calculate_trend_score(self, interest_data: pd.DataFrame, keyword: str, rising_queries: List[str]) -> float:
        """
        Calculate a trend score based on multiple factors

        Args:
            interest_data: Time series data from PyTrends
            keyword: The keyword being analyzed
            rising_queries: List of rising related queries

        Returns:
            Float score between 0-100
        """
        try:
            if interest_data.empty or keyword not in interest_data.columns:
                return 0.0

            values = interest_data[keyword].values

            # Remove zeros and get recent trend
            non_zero_values = values[values > 0]
            if len(non_zero_values) == 0:
                return 0.0

            # Calculate trend components
            avg_interest = np.mean(non_zero_values)
            recent_trend = np.mean(values[-4:]) if len(values) >= 4 else np.mean(values)
            max_interest = np.max(values)

            # Growth rate (recent vs earlier periods)
            if len(values) >= 8:
                early_avg = np.mean(values[:4])
                late_avg = np.mean(values[-4:])
                growth_rate = (late_avg - early_avg) / max(early_avg, 1) * 100
            else:
                growth_rate = 0

            # Bonus for rising queries
            rising_bonus = min(len(rising_queries) * 5, 20)

            # Calculate final score
            trend_score = (
                    avg_interest * 0.3 +
                    recent_trend * 0.4 +
                    max(growth_rate, 0) * 0.2 +
                    rising_bonus * 0.1
            )

            return min(trend_score, 100.0)

        except Exception as e:
            logger.error(f"Error calculating trend score: {str(e)}")
            return 0.0

    def _assess_market_potential(self, trend_score: float, rising_queries_count: int) -> str:
        """Assess market potential based on trend data"""
        if trend_score >= 70 and rising_queries_count >= 3:
            return "HIGH"
        elif trend_score >= 40 and rising_queries_count >= 1:
            return "MEDIUM"
        elif trend_score >= 20:
            return "LOW"
        else:
            return "MINIMAL"

    async def analyze_project_trends(self, project_description: str) -> Dict[str, Any]:
        """
        Main method to analyze trends for a project

        Args:
            project_description: Description of the project/business idea

        Returns:
            Comprehensive trend analysis report
        """
        logger.info(f"Starting trend analysis for project: {project_description[:100]}...")

        # Step 1: Generate keywords
        keywords_dict, all_keywords = await self.generate_keywords(project_description)

        # Step 2: Analyze trends for each category
        all_trend_data = []

        for category, keywords in keywords_dict.items():
            logger.info(f"Analyzing {len(keywords)} keywords in category: {category}")

            # Process keywords in batches of 5
            for i in range(0, len(keywords), 5):
                batch = keywords[i:i + 5]
                batch_results = self.analyze_keyword_batch(batch, category)
                all_trend_data.extend(batch_results)

                # Rate limiting between batches
                time.sleep(3)

        # Step 3: Rank and select top 10 trends
        top_trends = self._select_top_trends(all_trend_data, limit=10)

        # Step 4: Generate comprehensive report
        report = self._generate_trend_report(project_description, keywords_dict, top_trends, all_trend_data)

        logger.info(
            f"Analysis complete! Found {len(top_trends)} top trends with {len(all_trend_data)} total keywords analyzed")

        return report

    def _select_top_trends(self, trend_data: List[TrendData], limit: int = 10) -> List[TrendData]:
        """Select top trends based on trend score and market potential"""

        # Sort by trend score
        sorted_trends = sorted(trend_data, key=lambda x: x.trend_score, reverse=True)

        # Filter out minimal potential trends unless we don't have enough
        high_potential = [t for t in sorted_trends if t.market_potential in ['HIGH', 'MEDIUM']]

        if len(high_potential) >= limit:
            return high_potential[:limit]
        else:
            # Include some lower potential trends to reach limit
            remaining_needed = limit - len(high_potential)
            low_potential = [t for t in sorted_trends if t.market_potential in ['LOW']]
            return high_potential + low_potential[:remaining_needed]

    def _generate_trend_report(self, project: str, keywords_dict: Dict, top_trends: List[TrendData],
                               all_trends: List[TrendData]) -> Dict[str, Any]:
        """Generate comprehensive trend analysis report"""

        report = {
            "project_description": project,
            "analysis_timestamp": datetime.now().isoformat(),
            "summary": {
                "total_keywords_analyzed": len(all_trends),
                "top_trends_count": len(top_trends),
                "high_potential_count": len([t for t in top_trends if t.market_potential == 'HIGH']),
                "medium_potential_count": len([t for t in top_trends if t.market_potential == 'MEDIUM']),
                "low_potential_count": len([t for t in top_trends if t.market_potential == 'LOW'])
            },
            "keyword_categories": keywords_dict,
            "top_trends": [],
            "insights": {
                "market_opportunity": "",
                "trending_areas": [],
                "competitive_landscape": [],
                "recommendations": []
            }
        }

        # Process top trends
        for i, trend in enumerate(top_trends, 1):
            trend_info = {
                "rank": i,
                "keyword": trend.keyword,
                "category": trend.category,
                "trend_score": round(trend.trend_score, 2),
                "market_potential": trend.market_potential,
                "rising_queries": trend.rising_queries,
                "top_queries": trend.top_queries[:3],  # Limit for readability
                "key_insights": self._generate_keyword_insights(trend)
            }
            report["top_trends"].append(trend_info)

        # Generate overall insights
        report["insights"] = self._generate_market_insights(top_trends, all_trends)

        return report

    def _generate_keyword_insights(self, trend: TrendData) -> List[str]:
        """Generate insights for individual keywords"""
        insights = []

        if trend.trend_score > 70:
            insights.append("🔥 High search demand - strong market interest")
        elif trend.trend_score > 40:
            insights.append("📈 Moderate demand with growth potential")

        if len(trend.rising_queries) > 3:
            insights.append(f"🚀 {len(trend.rising_queries)} rising related queries indicate growing interest")

        if trend.market_potential == 'HIGH':
            insights.append("💰 High market potential - excellent opportunity")

        return insights

    def _generate_market_insights(self, top_trends: List[TrendData], all_trends: List[TrendData]) -> Dict[str, Any]:
        """Generate overall market insights"""

        # Analyze categories
        category_scores = defaultdict(list)
        for trend in top_trends:
            category_scores[trend.category].append(trend.trend_score)

        trending_areas = []
        for category, scores in category_scores.items():
            avg_score = sum(scores) / len(scores)
            trending_areas.append({
                "category": category,
                "average_score": round(avg_score, 2),
                "keyword_count": len(scores)
            })

        # Sort by score
        trending_areas.sort(key=lambda x: x['average_score'], reverse=True)

        # Generate recommendations
        recommendations = []

        if any(t.market_potential == 'HIGH' for t in top_trends):
            recommendations.append("🎯 Focus on high-potential keywords for immediate market entry")

        if len([t for t in top_trends if t.category == 'solution_seeking']) >= 3:
            recommendations.append("🔍 Strong solution-seeking behavior indicates unmet market demand")

        if sum(len(t.rising_queries) for t in top_trends) > 15:
            recommendations.append("📊 Multiple rising queries suggest emerging market trends")

        return {
            "market_opportunity": f"Analyzed {len(all_trends)} keywords with {len(top_trends)} showing strong potential",
            "trending_areas": trending_areas,
            "competitive_landscape": [t.keyword for t in top_trends if t.category == 'competitors'][:5],
            "recommendations": recommendations
        }

    def print_trend_report(self, report: Dict[str, Any]) -> None:
        """Print a formatted trend report to console"""

        print("\n" + "=" * 80)
        print("🚀 GOOGLE TRENDS MARKET ANALYSIS REPORT")
        print("=" * 80)

        print(f"\n📊 PROJECT: {report['project_description'][:100]}...")
        print(f"📅 ANALYZED: {report['analysis_timestamp']}")

        print(f"\n📈 SUMMARY:")
        summary = report['summary']
        print(f"   • Total Keywords Analyzed: {summary['total_keywords_analyzed']}")
        print(f"   • Top Trends Found: {summary['top_trends_count']}")
        print(f"   • High Potential: {summary['high_potential_count']}")
        print(f"   • Medium Potential: {summary['medium_potential_count']}")

        print(f"\n🏆 TOP 10 TRENDING OPPORTUNITIES:")
        print("-" * 80)

        for trend in report['top_trends']:
            print(f"\n#{trend['rank']:2d} | {trend['keyword'].upper()}")
            print(
                f"     Category: {trend['category']} | Score: {trend['trend_score']} | Potential: {trend['market_potential']}")

            if trend['rising_queries']:
                print(f"     🔥 Rising: {', '.join(trend['rising_queries'][:3])}")

            if trend['key_insights']:
                for insight in trend['key_insights'][:2]:
                    print(f"     {insight}")

        print(f"\n💡 KEY INSIGHTS:")
        insights = report['insights']
        print(f"   📊 {insights['market_opportunity']}")

        if insights['trending_areas']:
            print(f"\n   🏃‍♂️ Top Trending Areas:")
            for area in insights['trending_areas'][:3]:
                print(f"      • {area['category']}: {area['average_score']} avg score")

        if insights['recommendations']:
            print(f"\n   🎯 Recommendations:")
            for rec in insights['recommendations']:
                print(f"      • {rec}")

        print("\n" + "=" * 80)


# Example usage and testing
async def main():
    """Example usage of the Google PyTrends Agent"""

    # Initialize agent (replace with your OpenAI API key)
    OPENAI_API_KEY = "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"
    agent = GooglePyTrendsAgent(openai_api_key=OPENAI_API_KEY)

    # Example project
    project_description = """
    AI-powered autonomous business opportunity discovery platform that uses 
    multi-agent systems to find market gaps, validates them with real data, 
    and generates video demos and audio pitches for instant investor presentations
    """

    try:
        # Run the analysis
        report = await agent.analyze_project_trends(project_description)

        # Print formatted report
        agent.print_trend_report(report)

        # Save report to JSON
        with open('trend_analysis_report.json', 'w') as f:
            json.dump(report, f, indent=2, default=str)

        print("\n✅ Report saved to 'trend_analysis_report.json'")

    except Exception as e:
        print(f"❌ Error running analysis: {str(e)}")


if __name__ == "__main__":
    # Run the example
    asyncio.run(main())