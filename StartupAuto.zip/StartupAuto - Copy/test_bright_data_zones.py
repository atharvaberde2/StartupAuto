"""
Test both Bright Data zones: SERP API and Web Unlocker
"""
import asyncio
import aiohttp
import json
from config import Config

async def test_serp_zone():
    """Test SERP API zone"""
    config = Config()
    
    headers = {
        "Authorization": f"Bearer {config.BRIGHT_DATA_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Test SERP API zone
    serp_payload = {
        "zone": config.BRIGHT_DATA_SERP_ZONE,
        "url": "https://www.google.com/search?q=education+platforms",
        "format": "raw"
    }
    
    print("🔍 Testing SERP API Zone...")
    print(f"Zone: {config.BRIGHT_DATA_SERP_ZONE}")
    print(f"Payload: {serp_payload}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                config.BRIGHT_DATA_ENDPOINT,
                headers=headers,
                json=serp_payload,
                timeout=30
            ) as response:
                print(f"SERP Status Code: {response.status}")
                
                if response.status == 200:
                    data = await response.text()
                    print(f"✅ SERP API Working! Response length: {len(data)} chars")
                    # Check if it contains Google search results
                    if "google.com" in data.lower() and ("search" in data.lower() or "results" in data.lower()):
                        print("✅ Contains Google search results!")
                        return True
                    else:
                        print("⚠️ Response doesn't look like Google search results")
                        return False
                else:
                    error_text = await response.text()
                    print(f"❌ SERP API Failed: {error_text}")
                    return False
                    
    except Exception as e:
        print(f"❌ SERP API Error: {str(e)}")
        return False

async def test_unlocker_zone():
    """Test Web Unlocker zone"""
    config = Config()
    
    headers = {
        "Authorization": f"Bearer {config.BRIGHT_DATA_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Test Web Unlocker zone
    unlocker_payload = {
        "zone": config.BRIGHT_DATA_ZONE,
        "url": "https://www.coursera.org",
        "format": "raw"
    }
    
    print("\n🔍 Testing Web Unlocker Zone...")
    print(f"Zone: {config.BRIGHT_DATA_ZONE}")
    print(f"Payload: {unlocker_payload}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                config.BRIGHT_DATA_ENDPOINT,
                headers=headers,
                json=unlocker_payload,
                timeout=30
            ) as response:
                print(f"Unlocker Status Code: {response.status}")
                
                if response.status == 200:
                    data = await response.text()
                    print(f"✅ Web Unlocker Working! Response length: {len(data)} chars")
                    # Check if it contains website content
                    if "coursera" in data.lower():
                        print("✅ Contains Coursera website content!")
                        return True
                    else:
                        print("⚠️ Response doesn't look like Coursera content")
                        return False
                else:
                    error_text = await response.text()
                    print(f"❌ Web Unlocker Failed: {error_text}")
                    return False
                    
    except Exception as e:
        print(f"❌ Web Unlocker Error: {str(e)}")
        return False

async def test_both_zones():
    """Test both zones"""
    print("=" * 60)
    print("🚀 BRIGHT DATA ZONES TEST")
    print("=" * 60)
    
    serp_success = await test_serp_zone()
    unlocker_success = await test_unlocker_zone()
    
    print("\n" + "=" * 60)
    print("📊 FINAL RESULTS:")
    print(f"SERP API (serp_api1): {'✅ WORKING' if serp_success else '❌ FAILED'}")
    print(f"Web Unlocker (web_unlocker1): {'✅ WORKING' if unlocker_success else '❌ FAILED'}")
    
    if serp_success and unlocker_success:
        print("🎉 Both zones working perfectly!")
    elif serp_success or unlocker_success:
        print("⚠️ Partial success - one zone working")
    else:
        print("❌ Both zones failed")
    print("=" * 60)
    
    return serp_success and unlocker_success

if __name__ == "__main__":
    asyncio.run(test_both_zones())
