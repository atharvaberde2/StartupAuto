"""
Configuration file for Startup Autopilot
Contains all API keys and configuration settings
"""
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    # OpenAI Configuration
    OPENAI_API_KEY = "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"
    
    # Reddit API Configuration
    REDDIT_CLIENT_ID = "rWFSMJ5AuPPdHkPbWvoySg"
    REDDIT_CLIENT_SECRET = "_fk9tcrcdqEV8YWg57PVGAxHD-OjYQ"
    REDDIT_USER_AGENT = "StartupAutopilot/1.0"
    
    # News API Configuration
    NEWS_API_KEY = "fa207cf9d2d74e7db0c5238055a3c445"
    
    # Google Trends Configuration (uses OpenAI key)
    GOOGLE_TRENDS_OPENAI_KEY = "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"
    
    # Gemini API Configuration for Competitors Agent
    GEMINI_API_KEY = "AIzaSyCvPLsiZKzFbvKJEE0ty4a_va1voWVpOcU"
    
    # Bright Data API Configuration for SERP + Crawl APIs
    BRIGHT_DATA_API_KEY = os.getenv("BRIGHT_DATA_API_KEY", "3b04bf8daf2ce76e7f7e0dd1e9b96d4700de9e08ad58b946ced4ef756f30b7a2")
    BRIGHT_DATA_USERNAME = os.getenv("BRIGHT_DATA_USERNAME", "atberde100@gmail.com")
    BRIGHT_DATA_PASSWORD = os.getenv("BRIGHT_DATA_PASSWORD", "Donutbully123!@")
    BRIGHT_DATA_ZONE = os.getenv("BRIGHT_DATA_ZONE", "web_unlocker1")
    BRIGHT_DATA_SERP_ZONE = os.getenv("BRIGHT_DATA_SERP_ZONE", "serp_api1")
    BRIGHT_DATA_COLLECTOR_ID = os.getenv("BRIGHT_DATA_COLLECTOR_ID", "hl_e2c747c8")
    BRIGHT_DATA_ENDPOINT = "https://api.brightdata.com/request"
    
    # Flask Configuration
    DEBUG = True
    SECRET_KEY = "startup-autopilot-secret-key-2024"
    
    # Analysis Configuration - Optimized for REAL DATA QUALITY (not speed)
    MAX_REDDIT_THREADS = 50  # Full analysis for real validation
    MAX_NEWS_ARTICLES = 30   # Comprehensive news coverage
    MAX_COMPETITORS = 15     # Thorough competitor analysis
    ANALYSIS_TIMEOUT = 600   # 10 minutes for real data collection
    
    # Quality optimizations (no rushing)
    REDDIT_SEARCH_LIMIT = 25      # More comprehensive Reddit searches
    GOOGLE_TRENDS_KEYWORDS = 20   # Full trend keyword analysis
    COMPETITOR_ANALYSIS_DEPTH = 10 # Deep competitor analysis with real scraping
