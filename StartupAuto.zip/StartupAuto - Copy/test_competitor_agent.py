"""
Test the Competitor Agent with Bright Data integration
"""
import asyncio
from competitors import CompetitorAgent
from config import Config

async def test_competitor_agent():
    config = Config()
    
    # Initialize competitor agent with Bright Data config
    bright_data_config = {
        'api_key': config.BRIGHT_DATA_API_KEY
    }
    
    agent = CompetitorAgent(
        gemini_api_key=config.GEMINI_API_KEY,
        bright_data_config=bright_data_config
    )
    
    print("🔍 Testing Competitor Agent with Bright Data...")
    print(f"Using zone: {agent.config.BRIGHT_DATA_ZONE}")
    print(f"API endpoint: {agent.serp_api_url}")
    
    async with agent:
        try:
            print("\n🧪 Testing competitor analysis for 'AI education platforms'...")
            
            # Test competitor URLs for education platforms
            competitor_urls = [
                "https://www.coursera.org",
                "https://www.edx.org",
                "https://www.udacity.com"
            ]
            
            result = await agent.get_comprehensive_market_intelligence(
                "AI-powered education platform", 
                competitor_urls
            )
            
            if result and 'competitors' in result:
                print(f"✅ Analysis complete! Found data for {len(result['competitors'])} competitors")
                print(f"Market maturity: {result.get('market_maturity', 'unknown')}")
                print(f"Competitive intensity: {result.get('competitive_intensity', 'unknown')}")
                return True
            else:
                print("❌ No competitor analysis data returned")
                return False
                
        except Exception as e:
            print(f"❌ Test failed: {str(e)}")
            return False

if __name__ == "__main__":
    print("=" * 60)
    print("🚀 COMPETITOR AGENT TEST")
    print("=" * 60)
    
    success = asyncio.run(test_competitor_agent())
    
    print("\n" + "=" * 60)
    if success:
        print("✅ Competitor Agent working with Bright Data!")
    else:
        print("❌ Competitor Agent issues")
    print("=" * 60)