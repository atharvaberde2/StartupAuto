#!/usr/bin/env python3
"""
Test script for Stage 3 Advertisement Generation System
Tests the complete pipeline from Stages 1-2 to Stage 3 ad generation
"""

import requests
import json
import time
import sys

def test_ad_generation_pipeline():
    """Test the complete advertisement generation pipeline"""
    
    print("🎬 Testing Stage 3 Advertisement Generation Pipeline")
    print("=" * 60)
    
    # Base URL for the Flask app
    base_url = "http://localhost:5001"
    
    # Test business data (from Stages 1-2)
    test_business = {
        "name": "AI Market Validator Pro",
        "analysis": {
            "viability_score": 87,
            "reddit_analysis": {
                "total_market_size": 250000,
                "threads_found": 45,
                "validation_score": 85
            },
            "revenue_analysis": {
                "growth_forecast": {
                    "month_12": {
                        "annual_run_rate": 8500000
                    }
                },
                "ml_confidence": {
                    "overall_confidence_score": 89
                }
            },
            "competitive_landscape": {
                "total_competitors": 12,
                "market_maturity": "emerging"
            }
        }
    }
    
    print(f"📊 Business: {test_business['name']}")
    print(f"📈 Validation Score: {test_business['analysis']['viability_score']}%")
    print(f"💰 Revenue Projection: ${test_business['analysis']['revenue_analysis']['growth_forecast']['month_12']['annual_run_rate'] / 1000000:.1f}M")
    print()
    
    # Test 1: Voice Generation (ElevenLabs)
    print("🎙️ Testing Voice Pitch Generation...")
    try:
        voice_response = requests.post(
            f"{base_url}/api/generate-voice",
            json={
                "business_name": test_business["name"],
                "business_data": test_business["analysis"],
                "voice_type": "professional_male",
                "elevenlabs_voice_id": "pNInz6obpgDQGcFmaJgB",
                "stability": 0.5,
                "similarity_boost": 0.75
            },
            timeout=30
        )
        
        if voice_response.status_code == 200:
            voice_result = voice_response.json()
            print("✅ Voice generation successful!")
            print(f"   Audio URL: {voice_result['audio_url']}")
            print(f"   Duration: {voice_result['duration']}")
            print(f"   ElevenLabs Voice ID: {voice_result['elevenlabs_voice_id']}")
            print(f"   Script Length: {len(voice_result['script'])} characters")
        else:
            print(f"❌ Voice generation failed: {voice_response.status_code}")
            print(f"   Error: {voice_response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Voice generation request failed: {e}")
    
    print()
    
    # Test 2: Video Generation (Google Veo 3)
    print("🎥 Testing Video Demo Generation...")
    try:
        video_response = requests.post(
            f"{base_url}/api/generate-video",
            json={
                "business_name": test_business["name"],
                "business_data": test_business["analysis"],
                "video_style": "professional_demo",
                "veo3_model": "google/veo-3",
                "resolution": "1080p",
                "aspect_ratio": "16:9",
                "duration": 75,
                "style_preset": "corporate_professional",
                "fast": True  # Use fast mode for testing
            },
            timeout=300  # 5 minute timeout for real Veo 3 generation
        )
        
        if video_response.status_code == 200:
            video_result = video_response.json()
            print("✅ Video generation successful!")
            print(f"   Video URL: {video_result['video_url']}")
            print(f"   Duration: {video_result['duration']}")
            print(f"   Resolution: {video_result['resolution']}")
            print(f"   Veo 3 Model: {video_result['veo3_model']}")
            print(f"   Style: {video_result['style_preset']}")
            
            # Check if real Veo 3 was used
            if video_result.get('fallback_mode'):
                print("   ⚠️  Using fallback mode (Veo 3 not configured)")
            elif video_result.get('generation_time'):
                print(f"   ✅ Real Veo 3 generation (took {video_result['generation_time']}s)")
            else:
                print("   ✅ Veo 3 processing successful")
                
        else:
            print(f"❌ Video generation failed: {video_response.status_code}")
            print(f"   Error: {video_response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Video generation request failed: {e}")
    
    print()
    
    # Test 3: Complete Package Generation
    print("📦 Testing Complete Advertisement Package...")
    try:
        package_response = requests.post(
            f"{base_url}/api/generate-package",
            json={
                "business_name": test_business["name"],
                "audio_id": "voice_test_123",
                "video_id": "video_test_456"
            },
            timeout=20
        )
        
        if package_response.status_code == 200:
            package_result = package_response.json()
            print("✅ Complete package generation successful!")
            print(f"   Package URL: {package_result['package_url']}")
            print(f"   Package Size: {package_result['package_size']}")
            print(f"   Contents: {len(package_result['contents'])} files")
            for content in package_result['contents']:
                print(f"     - {content}")
        else:
            print(f"❌ Package generation failed: {package_response.status_code}")
            print(f"   Error: {package_response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Package generation request failed: {e}")
    
    print()
    print("🎯 Stage 3 Advertisement Generation Testing Complete!")
    print("=" * 60)
    print()
    print("🚀 Integration Points:")
    print("   • Stage 1 (Market Research) → Business validation data")
    print("   • Stage 2 (AI Validation) → Opportunity scoring")
    print("   • Stage 3 (Ad Generation) → Multi-modal prototypes")
    print()
    print("🎬 Generated Assets:")
    print("   • Professional voice pitch (ElevenLabs)")
    print("   • Product demo video (Google Veo 3)")
    print("   • Complete marketing package")
    print()
    print("✨ Ready for investor presentations and market launch!")

def test_server_connectivity():
    """Test if the Flask server is running"""
    try:
        response = requests.get("http://localhost:5001/api/test", timeout=5)
        if response.status_code == 200:
            print("✅ Flask server is running and accessible")
            return True
        else:
            print(f"❌ Server responded with status {response.status_code}")
            return False
    except requests.exceptions.RequestException:
        print("❌ Cannot connect to Flask server on localhost:5001")
        print("   Please ensure the Flask app is running with: python app.py")
        return False

if __name__ == "__main__":
    print("🎬 Stage 3 Advertisement Generation Test Suite")
    print("=" * 50)
    print()
    
    # Test server connectivity first
    if test_server_connectivity():
        print()
        test_ad_generation_pipeline()
    else:
        print()
        print("💡 To start the server, run:")
        print("   python app.py")
        print()
        sys.exit(1)
