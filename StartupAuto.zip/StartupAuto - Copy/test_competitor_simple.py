"""
Simple test to see what competitor agent returns
"""
import asyncio
from competitors import CompetitorAgent
from config import Config

async def test_simple():
    config = Config()
    
    bright_data_config = {
        'api_key': config.BRIGHT_DATA_API_KEY
    }
    
    agent = CompetitorAgent(
        gemini_api_key=config.GEMINI_API_KEY,
        bright_data_config=bright_data_config
    )
    
    async with agent:
        try:
            # Test the SERP search directly
            print("🧪 Testing SERP search directly...")
            serp_results = await agent._bright_data_serp_search("education platforms", 5)
            print(f"SERP Results: {len(serp_results)} items")
            
            for i, result in enumerate(serp_results[:3], 1):
                print(f"{i}. {result.get('title', 'No title')}")
                print(f"   Domain: {result.get('domain', 'No domain')}")
                print(f"   URL: {result.get('link', 'No URL')}")
                print()
            
            # Test crawl search directly
            print("🧪 Testing crawl search directly...")
            crawl_result = await agent._bright_data_crawl_competitor("https://www.coursera.org")
            print(f"Crawl Result keys: {list(crawl_result.keys())}")
            print(f"Quality score: {crawl_result.get('quality_score', 'N/A')}")
            print(f"HTML length: {crawl_result.get('html_length', 'N/A')}")
            
            return len(serp_results) > 0
            
        except Exception as e:
            print(f"❌ Error: {str(e)}")
            import traceback
            traceback.print_exc()
            return False

if __name__ == "__main__":
    success = asyncio.run(test_simple())
    print(f"\n{'✅ SUCCESS' if success else '❌ FAILED'}")
