"""
Debug the exact request being sent by competitor agent
"""
import asyncio
import aiohttp
import json
from config import Config

async def debug_serp_request():
    """Debug the SERP request format"""
    config = Config()
    
    # This is what the competitor agent is sending
    payload = {
        "zone": config.BRIGHT_DATA_ZONE,
        "url": "https://www.google.com/search?q=education+platforms&num=10",
        "format": "json",
        "country": "US",
        "render": True,
        "parser": {
            "organic_results": True,
            "ads": True,
            "related_searches": True,
            "people_also_ask": True
        }
    }
    
    headers = {
        "Authorization": f"Bearer {config.BRIGHT_DATA_API_KEY}",
        "Content-Type": "application/json"
    }
    
    print("🔍 Debugging SERP request...")
    print(f"Endpoint: {config.BRIGHT_DATA_ENDPOINT}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                config.BRIGHT_DATA_ENDPOINT,
                headers=headers,
                json=payload,
                timeout=30
            ) as response:
                print(f"\nStatus Code: {response.status}")
                response_text = await response.text()
                print(f"Response: {response_text}")
                
                if response.status != 200:
                    print("\n❌ Request failed - let's try simplified version...")
                    
                    # Try simplified payload (like our working test)
                    simple_payload = {
                        "zone": config.BRIGHT_DATA_ZONE,
                        "url": "https://www.google.com/search?q=education+platforms",
                        "format": "json"
                    }
                    
                    print(f"Simplified payload: {json.dumps(simple_payload, indent=2)}")
                    
                    async with session.post(
                        config.BRIGHT_DATA_ENDPOINT,
                        headers=headers,
                        json=simple_payload,
                        timeout=30
                    ) as response2:
                        print(f"\nSimplified Status Code: {response2.status}")
                        simplified_response = await response2.text()
                        print(f"Simplified Response: {simplified_response[:500]}...")
                        
                        return response2.status == 200
                        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return False

if __name__ == "__main__":
    asyncio.run(debug_serp_request())
