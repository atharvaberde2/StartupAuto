#!/usr/bin/env python3
"""
Direct test of Google Veo 3 integration with your API key
Tests the Veo 3 video generation without requiring Flask server
"""

import os
import time
from veo3_integration import generate_business_video_for_api, BusinessVeo3Client

def test_veo3_connection():
    """Test Google Veo 3 API connection"""
    print("🎥 Testing Google Veo 3 Connection")
    print("=" * 50)
    
    # Check API key
    api_key = os.environ.get('GOOGLE_API_KEY')
    if api_key:
        print(f"✅ API Key configured: {api_key[:20]}...")
    else:
        print("❌ No GOOGLE_API_KEY found in environment")
        return False
    
    # Test client initialization
    try:
        client = BusinessVeo3Client()
        print("✅ BusinessVeo3Client initialized successfully")
    except Exception as e:
        print(f"❌ Client initialization failed: {e}")
        return False
    
    return True

def test_prompt_generation():
    """Test business-specific prompt generation"""
    print("\n🎬 Testing Business Prompt Generation")
    print("=" * 50)
    
    # Sample business data (from your Stage 1-2)
    test_business_data = {
        "viability_score": 87,
        "reddit_analysis": {
            "total_market_size": 250000,
            "threads_found": 45
        },
        "revenue_analysis": {
            "growth_forecast": {
                "month_12": {
                    "annual_run_rate": 8500000
                }
            }
        }
    }
    
    try:
        client = BusinessVeo3Client()
        prompt = client._build_business_prompt(
            business_name="AI Market Validator Pro",
            business_data=test_business_data,
            style="professional_demo",
            duration=75
        )
        
        print("✅ Business prompt generated successfully!")
        print(f"\n📝 Generated Prompt Preview:")
        print("-" * 40)
        print(prompt[:300] + "..." if len(prompt) > 300 else prompt)
        print("-" * 40)
        
        return True
        
    except Exception as e:
        print(f"❌ Prompt generation failed: {e}")
        return False

def test_api_integration():
    """Test the Flask API integration function"""
    print("\n🔧 Testing API Integration Function")
    print("=" * 50)
    
    test_business_data = {
        "viability_score": 87,
        "reddit_analysis": {"total_market_size": 250000},
        "revenue_analysis": {
            "growth_forecast": {"month_12": {"annual_run_rate": 8500000}}
        }
    }
    
    video_params = {
        "video_style": "professional_demo",
        "resolution": "1080p",
        "aspect_ratio": "16:9",
        "fast": True,  # Use fast mode for testing
        "duration": 30  # Shorter for testing
    }
    
    try:
        print("🎬 Testing video generation API function...")
        print("⏳ This may take 2-5 minutes for real Veo 3 generation...")
        
        start_time = time.time()
        result = generate_business_video_for_api(
            business_name="AI Market Validator Pro",
            business_data=test_business_data,
            video_params=video_params
        )
        end_time = time.time()
        
        if result.get("success"):
            print("✅ Video generation API test successful!")
            print(f"   Generation time: {end_time - start_time:.1f} seconds")
            print(f"   Video URL: {result.get('video_url', 'N/A')}")
            print(f"   Model used: {result.get('model', 'N/A')}")
            print(f"   File size: {result.get('file_size_mb', 'N/A')} MB")
            
            # Check if it's a real Veo 3 generation or fallback
            if result.get('generation_time', 0) > 60:
                print("   🎯 Real Google Veo 3 generation detected!")
            else:
                print("   ⚠️  Fallback mode (check API key and permissions)")
            
            return True
        else:
            print(f"❌ Video generation failed: {result.get('error', 'Unknown error')}")
            return False
            
    except Exception as e:
        print(f"❌ API integration test failed: {e}")
        return False

def main():
    """Run all Veo 3 tests"""
    print("🎬 Google Veo 3 Direct Integration Test")
    print("=" * 60)
    print(f"🕒 Started at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    tests = [
        ("Connection Test", test_veo3_connection),
        ("Prompt Generation", test_prompt_generation),
        ("API Integration", test_api_integration)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n🧪 Running: {test_name}")
        try:
            success = test_func()
            results.append((test_name, success))
        except Exception as e:
            print(f"❌ {test_name} crashed: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("🎯 TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for _, success in results if success)
    total = len(results)
    
    for test_name, success in results:
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"   {status}: {test_name}")
    
    print(f"\n📊 Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Google Veo 3 integration is working!")
        print("\n🚀 Your Stage 3 system is ready for professional video generation!")
        print("\n💡 Next steps:")
        print("   1. Run: python app.py")
        print("   2. Open: http://localhost:5001")
        print("   3. Generate a business idea and click 'Generate Advertisements'")
        print("   4. Create stunning videos with real Google Veo 3!")
    else:
        print("\n⚠️  Some tests failed. Check the errors above.")
        print("\n🔧 Troubleshooting:")
        print("   - Verify API key is correct")
        print("   - Check internet connection")  
        print("   - Ensure google-genai package is installed")

if __name__ == "__main__":
    main()
