"""
Test Bright Data Web Scraper API (different from DCA)
"""
import asyncio
import aiohttp
import json
from config import Config
import base64

async def test_bright_data_webscraper():
    """Test Bright Data Web Scraper API"""
    config = Config()
    
    print("🔍 Testing Bright Data Web Scraper API...")
    print(f"Username: {config.BRIGHT_DATA_USERNAME}")
    print(f"Collector: {config.BRIGHT_DATA_COLLECTOR_ID}")
    
    # Web Scraper API endpoint
    endpoint = f"https://{config.BRIGHT_DATA_COLLECTOR_ID}.brightdata.com"
    
    # Basic Auth credentials
    credentials = f"{config.BRIGHT_DATA_USERNAME}:{config.BRIGHT_DATA_PASSWORD}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    
    headers = {
        "Authorization": f"Basic {encoded_credentials}",
        "Content-Type": "application/json"
    }
    
    # Test payload for web scraper
    test_payload = {
        "url": "https://httpbin.org/get",
        "format": "json"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            print(f"\n📡 Testing Web Scraper endpoint: {endpoint}")
            print(f"Payload: {test_payload}")
            
            async with session.post(endpoint, headers=headers, json=test_payload, timeout=30) as response:
                print(f"Status Code: {response.status}")
                print(f"Response Headers: {dict(response.headers)}")
                
                if response.status == 200:
                    data = await response.json()
                    print(f"✅ Web Scraper API Working!")
                    print(f"Response preview: {json.dumps(data, indent=2)[:300]}...")
                    return True
                else:
                    response_text = await response.text()
                    print(f"❌ API Error: {response_text}")
                    return False
                    
    except Exception as e:
        print(f"❌ Connection error: {str(e)}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("🚀 BRIGHT DATA WEB SCRAPER TEST")
    print("=" * 60)
    
    success = asyncio.run(test_bright_data_webscraper())
    
    print("\n" + "=" * 60)
    if success:
        print("✅ Web Scraper API working!")
    else:
        print("❌ Web Scraper API issues")
    print("=" * 60)
