"""
Test Google search with Bright Data Web Unlocker
"""
import asyncio
import aiohttp
from config import Config

async def test_google_search():
    config = Config()
    
    headers = {
        "Authorization": f"Bearer {config.BRIGHT_DATA_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Test different Google search URL formats
    test_queries = [
        "https://www.google.com/search?q=education+platforms",
        "https://google.com/search?q=education+platforms", 
        "https://www.google.com/search?q=education%20platforms",
        "https://google.com/search?q=online%20education",
    ]
    
    print("🔍 Testing Google search URLs with Web Unlocker...")
    
    async with aiohttp.ClientSession() as session:
        for i, search_url in enumerate(test_queries, 1):
            payload = {
                "zone": config.BRIGHT_DATA_ZONE,
                "url": search_url,
                "format": "raw"
            }
            
            print(f"\n🧪 Test {i}/4: {search_url}")
            
            try:
                async with session.post(
                    config.BRIGHT_DATA_ENDPOINT,
                    headers=headers,
                    json=payload,
                    timeout=30
                ) as response:
                    print(f"Status: {response.status}")
                    
                    if response.status == 200:
                        data = await response.text()
                        print(f"✅ SUCCESS! Response length: {len(data)} chars")
                        
                        # Check if it contains search results
                        education_competitors = ['coursera', 'edx', 'udacity', 'khan']
                        found_competitors = [comp for comp in education_competitors if comp in data.lower()]
                        
                        if found_competitors:
                            print(f"🎯 Found competitors: {found_competitors}")
                            return True
                        else:
                            print("⚠️ No education competitors found in results")
                    else:
                        error_text = await response.text()
                        print(f"❌ Failed: {error_text}")
                        
            except Exception as e:
                print(f"❌ Error: {str(e)}")
                
            print("-" * 50)
    
    return False

if __name__ == "__main__":
    asyncio.run(test_google_search())
